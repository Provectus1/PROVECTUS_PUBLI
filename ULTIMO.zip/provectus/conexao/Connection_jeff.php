<?php

class Connection {

    //atributos
    public $connection;

    public function __construct() {
        $this->connection = new PDO("mysql:host=localhost;dbname=provectus;", "aluno","aluno");
    }

    public function getConnection(){
        return $this->connection;
    }


}
$teste = new Connection;
print_r($teste);
?>