<?php 

/* Primeiro teste 
class Connection{
	private $user,$pwd,$base,$server,$connection;
	public function __construct($user,$pwd,$base,$server){
		$this->servidor = $server;
		$this->banco = $base;
		$this->usuario = $user;
		$this->senha = $pwd;

		$this->connection = new PDO("mysql:host=localhost;provectus;", "aluno","aluno");
	}

	public function getConnection(){
		try{
			$this->connection = new PDO("mysql:host=localhost;provectus;", "aluno","aluno");
			return $this->connection;
		}catch(Exception $erro){
			print_r($erro);
		}
	}
}

$conexao = new Connection("aluno","aluno","provectus","localhost");
print_r($conexao);
*/

class Connection {

    //atributos
    public $connection;

    public function __construct() {
        $this->connection = new PDO("mysql:host=localhost;dbname=provectus;", "aluno","aluno");
    }

    public function getConnection(){
        return $this->connection;
    }


}
//$teste = new Connection;
//print_r($teste);
