-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 25/11/2019 às 17:32
-- Versão do servidor: 5.7.24-0ubuntu0.18.04.1
-- Versão do PHP: 7.2.13-1+ubuntu18.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `provectus`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `artigo`
--

CREATE TABLE `artigo` (
  `conteudo` varchar(2500) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `autor` varchar(50) DEFAULT NULL,
  `dat` date NOT NULL,
  `cod_arti` int(3) NOT NULL,
  `cd_cod_filtro` int(1) DEFAULT NULL,
  `cd_cod_cat` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `artigo`
--

INSERT INTO `artigo` (`conteudo`, `titulo`, `autor`, `dat`, `cod_arti`, `cd_cod_filtro`, `cd_cod_cat`) VALUES
(' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.  Um texto pode ser codificado, sendo formado de acordo com um cÃ³digo determinado impeditivo da sua leitura direta.  Um texto tem tamanho variÃ¡vel e deve ser escrito com coesÃ£o e coerÃªncia. Pode ser classificado como literÃ¡rio e nÃ£o-literÃ¡rio.  Os textos literÃ¡rios apresentam uma funÃ§Ã£o estÃ©tica. Geralmente sÃ£o escritos em linguagem expressiva e poÃ©tica, com o objetivo de atrair o interesse e emocionar o leitor. O autor segue um determinado estilo e usa as palavras de forma harmoniosa para expressar as suas ideias. HÃ¡ uma predominÃ¢ncia da funÃ§Ã£o poÃ©tica e da linguagem conotativa (subjetiva). SÃ£o exemplos de textos literÃ¡rios: romances, poesias, contos, novelas, textos sagrados, etc.', 'VocÃª reconhece os 10 principais sintomas do estresse?', 'Laryssa Sarti', '2019-11-06', 20, 1, 2),
(' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.  Um texto pode ser codificado, sendo formado de acordo com um cÃ³digo determinado impeditivo da sua leitura direta.  Um texto tem tamanho variÃ¡vel e deve ser escrito com coesÃ£o e coerÃªncia. Pode ser classificado como literÃ¡rio e nÃ£o-literÃ¡rio.  Os textos literÃ¡rios apresentam uma funÃ§Ã£o estÃ©tica. Geralmente sÃ£o escritos em linguagem expressiva e poÃ©tica, com o objetivo de atrair o interesse e emocionar o leitor. O autor segue um determinado estilo e usa as palavras de forma harmoniosa para expressar as suas ideias. HÃ¡ uma predominÃ¢ncia da funÃ§Ã£o poÃ©tica e da linguagem conotativa (subjetiva). SÃ£o exemplos de textos literÃ¡rios: romances, poesias, contos, novelas, textos sagrados, etc.  Os textos nÃ£o-literÃ¡rios possuem funÃ§Ã£o utilitÃ¡ria ao informar e explicar ao leitor de forma clara e objetiva. SÃ£o textos informativos sem preocupaÃ§Ã£o estÃ©tica. HÃ¡ uma predominÃ¢ncia da funÃ§Ã£o referencial e da linguagem denotativa (objetiva). SÃ£o exemplos de textos nÃ£o-literÃ¡rios: notÃ­cias e reportagens jornalÃ­sticas, textos cientÃ­ficos e didÃ¡ticos, etc.', '5 doenÃ§as hereditÃ¡rias comuns', 'Laryssa Sarti', '2019-11-14', 21, 1, 2),
(' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.  Um texto pode ser codificado, sendo formado de acordo com um cÃ³digo determinado impeditivo da sua leitura direta.  Um texto tem tamanho variÃ¡vel e deve ser escrito com coesÃ£o e coerÃªncia. Pode ser classificado como literÃ¡rio e nÃ£o-literÃ¡rio.  Os textos literÃ¡rios apresentam uma funÃ§Ã£o estÃ©tica. Geralmente sÃ£o escritos em linguagem expressiva e poÃ©tica, com o objetivo de atrair o interesse e emocionar o leitor. O autor segue um determinado estilo e usa as palavras de forma harmoniosa para expressar as suas ideias. HÃ¡ uma predominÃ¢ncia da funÃ§Ã£o poÃ©tica e da linguagem conotativa (subjetiva). SÃ£o exemplos de textos literÃ¡rios: romances, poesias, contos, novelas, textos sagrados, etc.  Os textos nÃ£o-literÃ¡rios possuem funÃ§Ã£o utilitÃ¡ria ao informar e explicar ao leitor de forma clara e objetiva. SÃ£o textos informativos sem preocupaÃ§Ã£o estÃ©tica. HÃ¡ uma predominÃ¢ncia da funÃ§Ã£o referencial e da linguagem denotativa (objetiva). SÃ£o exemplos de textos nÃ£o-literÃ¡rios: notÃ­cias e reportagens jornalÃ­sticas, textos cientÃ­ficos e didÃ¡ticos, etc.', 'Como ter um dia extremamente produtivo seguindo 3 regras bÃ¡sicas', 'Clara Souza', '2019-11-23', 22, 1, 2),
(' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.  Um texto pode ser codificado, sendo formado de acordo com um cÃ³digo determinado impeditivo da sua leitura direta.  Um texto tem tamanho variÃ¡vel e deve ser escrito com coesÃ£o e coerÃªncia. Pode ser classificado como literÃ¡rio e nÃ£o-literÃ¡rio.  Os textos literÃ¡rios apresentam uma funÃ§Ã£o estÃ©tica. Geralmente sÃ£o escritos em linguagem expressiva e poÃ©tica, com o objetivo de atrair o interesse e emocionar o leitor. O autor segue um determinado estilo e usa as palavras de forma harmoniosa para expressar as suas ideias. HÃ¡ uma predominÃ¢ncia da funÃ§Ã£o poÃ©tica e da linguagem conotativa (subjetiva). SÃ£o exemplos de textos literÃ¡rios: romances, poesias, contos, novelas, textos sagrados, etc.  Os textos nÃ£o-literÃ¡rios possuem funÃ§Ã£o utilitÃ¡ria ao informar e explicar ao leitor de forma clara e objetiva. SÃ£o textos informativos sem preocupaÃ§Ã£o estÃ©tica. HÃ¡ uma predominÃ¢ncia da funÃ§Ã£o referencial e da linguagem denotativa (objetiva). SÃ£o exemplos de textos nÃ£o-literÃ¡rios: notÃ­cias e reportagens jornalÃ­sticas, textos cientÃ­ficos e didÃ¡ticos, etc. Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.  Um texto pode ser codificado, sendo formado de acordo com um cÃ³digo determinado impeditivo da sua leitura direta.  Um texto tem tamanho variÃ¡vel e deve ser escr', 'Como fazer atividade fÃ­sica sem comprometer o seu tempo: 4 maneiras eficientes', 'Tuane Ronchi ', '2019-11-18', 23, 1, 2),
(' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.  Um texto pode ser codificado, sendo formado de acordo com um cÃ³digo determinado impeditivo da sua leitura direta.  Um texto tem tamanho variÃ¡vel e deve ser escrito com coesÃ£o e coerÃªncia. Pode ser classificado como literÃ¡rio e nÃ£o-literÃ¡rio.  Os textos literÃ¡rios apresentam uma funÃ§Ã£o estÃ©tica. Geralmente sÃ£o escritos em linguagem expressiva e poÃ©tica, com o objetivo de atrair o interesse e emocionar o leitor. O autor segue um determinado estilo e usa as palavras de forma harmoniosa para expressar as suas ideias. HÃ¡ uma predominÃ¢ncia da funÃ§Ã£o poÃ©tica e da linguagem conotativa (subjetiva). SÃ£o exemplos de textos literÃ¡rios: romances, poesias, contos, novelas, textos sagrados, etc.  Os textos nÃ£o-literÃ¡rios possuem funÃ§Ã£o utilitÃ¡ria ao informar e explicar ao leitor de forma clara e objetiva. SÃ£o textos informativos sem preocupaÃ§Ã£o estÃ©tica. HÃ¡ uma predominÃ¢ncia da funÃ§Ã£o referencial e da linguagem denotativa (objetiva). SÃ£o exemplos de textos nÃ£o-literÃ¡rios: notÃ­cias e reportagens jornalÃ­sticas, textos cientÃ­ficos e didÃ¡ticos, etc. Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.  Um texto pode ser codificado, sendo formado de acordo com um cÃ³digo determinado impeditivo da sua leitura direta.  Um texto tem tamanho variÃ¡vel e deve ser escr', '10 motivos para inserir a Yoga como uma atividade semanal na sua rotina', 'Clara Souza', '2019-11-21', 24, 1, 2),
(' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.  Um texto pode ser codificado, sendo formado de acordo com um cÃ³digo determinado impeditivo da sua leitura direta.  Um texto tem tamanho variÃ¡vel e deve ser escrito com coesÃ£o e coerÃªncia. Pode ser classificado como literÃ¡rio e nÃ£o-literÃ¡rio.  Os textos literÃ¡rios apresentam uma funÃ§Ã£o estÃ©tica. Geralmente sÃ£o escritos em linguagem expressiva e poÃ©tica, com o objetivo de atrair o interesse e emocionar o leitor. O autor segue um determinado estilo e usa as palavras de forma harmoniosa para expressar as suas ideias. HÃ¡ uma predominÃ¢ncia da funÃ§Ã£o poÃ©tica e da linguagem conotativa (subjetiva). SÃ£o exemplos de textos literÃ¡rios: romances, poesias, contos, novelas, textos sagrados, etc.  Os textos nÃ£o-literÃ¡rios possuem funÃ§Ã£o utilitÃ¡ria ao informar e explicar ao leitor de forma clara e objetiva. SÃ£o textos informativos sem preocupaÃ§Ã£o estÃ©tica. HÃ¡ uma predominÃ¢ncia da funÃ§Ã£o referencial e da linguagem denotativa (objetiva). SÃ£o exemplos de textos nÃ£o-literÃ¡rios: notÃ­cias e reportagens jornalÃ­sticas, textos cientÃ­ficos e didÃ¡ticos, etc. Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.  Um texto pode ser codificado, sendo formado de acordo com um cÃ³digo determinado impeditivo da sua leitura direta.  Um texto tem tamanho variÃ¡vel e deve ser escr', 'VocÃª nÃ£o precisa acordar cedo para ter um dia mais produtivo', 'Tuane Ronchi', '2019-11-30', 25, 1, 2),
(' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.  Um texto pode ser codificado, sendo formado de acordo com um cÃ³digo determinado impeditivo da sua leitura direta.  Um texto tem tamanho variÃ¡vel e deve ser escrito com coesÃ£o e coerÃªncia. Pode ser classificado como literÃ¡rio e nÃ£o-literÃ¡rio.  Os textos literÃ¡rios apresentam uma funÃ§Ã£o estÃ©tica. Geralmente sÃ£o escritos em linguagem expressiva e poÃ©tica, com o objetivo de atrair o interesse e emocionar o leitor. O autor segue um determinado estilo e usa as palavras de forma harmoniosa para expressar as suas ideias. HÃ¡ uma predominÃ¢ncia da funÃ§Ã£o poÃ©tica e da linguagem conotativa (subjetiva). SÃ£o exemplos de textos literÃ¡rios: romances, poesias, contos, novelas, textos sagrados, etc.  Os textos nÃ£o-literÃ¡rios possuem funÃ§Ã£o utilitÃ¡ria ao informar e explicar ao leitor de forma clara e objetiva. SÃ£o textos informativos sem preocupaÃ§Ã£o estÃ©tica. HÃ¡ uma predominÃ¢ncia da funÃ§Ã£o referencial e da linguagem denotativa (objetiva). SÃ£o exemplos de textos nÃ£o-literÃ¡rios: notÃ­cias e reportagens jornalÃ­sticas, textos cientÃ­ficos e didÃ¡ticos, etc. Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.  Um texto pode ser codificado, sendo formado de acordo com um cÃ³digo determinado impeditivo da sua leitura direta.  Um texto tem tamanho variÃ¡vel e deve ser escr', 'VocÃª nÃ£o precisa ser rico para fazer viagens internacionais', 'Laryssa Sarti', '2019-11-30', 26, 1, 1),
(' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.  Um texto pode ser codificado, sendo formado de acordo com um cÃ³digo determinado impeditivo da sua leitura direta.  Um texto tem tamanho variÃ¡vel e deve ser escrito com coesÃ£o e coerÃªncia. Pode ser classificado como literÃ¡rio e nÃ£o-literÃ¡rio.  Os textos literÃ¡rios apresentam uma funÃ§Ã£o estÃ©tica. Geralmente sÃ£o escritos em linguagem expressiva e poÃ©tica, com o objetivo de atrair o interesse e emocionar o leitor. O autor segue um determinado estilo e usa as palavras de forma harmoniosa para expressar as suas ideias. HÃ¡ uma predominÃ¢ncia da funÃ§Ã£o poÃ©tica e da linguagem conotativa (subjetiva). SÃ£o exemplos de textos literÃ¡rios: romances, poesias, contos, novelas, textos sagrados, etc.  Os textos nÃ£o-literÃ¡rios possuem funÃ§Ã£o utilitÃ¡ria ao informar e explicar ao leitor de forma clara e objetiva. SÃ£o textos informativos sem preocupaÃ§Ã£o estÃ©tica. HÃ¡ uma predominÃ¢ncia da funÃ§Ã£o referencial e da linguagem denotativa (objetiva). SÃ£o exemplos de textos nÃ£o-literÃ¡rios: notÃ­cias e reportagens jornalÃ­sticas, textos cientÃ­ficos e didÃ¡ticos, etc. Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.  Um texto pode ser codificado, sendo formado de acordo com um cÃ³digo determinado impeditivo da sua leitura direta.  Um texto tem tamanho variÃ¡vel e deve ser escr', '50 razÃµes que provam porque todo mundo deveria ir para a Disney ao menos 1 vez na vida', 'Clara Souza', '2019-11-10', 27, 1, 1),
(' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.  Um texto pode ser codificado, sendo formado de acordo com um cÃ³digo determinado impeditivo da sua leitura direta.  Um texto tem tamanho variÃ¡vel e deve ser escrito com coesÃ£o e coerÃªncia. Pode ser classificado como literÃ¡rio e nÃ£o-literÃ¡rio.  Os textos literÃ¡rios apresentam uma funÃ§Ã£o estÃ©tica. Geralmente sÃ£o escritos em linguagem expressiva e poÃ©tica, com o objetivo de atrair o interesse e emocionar o leitor. O autor segue um determinado estilo e usa as palavras de forma harmoniosa para expressar as suas ideias. HÃ¡ uma predominÃ¢ncia da funÃ§Ã£o poÃ©tica e da linguagem conotativa (subjetiva). SÃ£o exemplos de textos literÃ¡rios: romances, poesias, contos, novelas, textos sagrados, etc.  Os textos nÃ£o-literÃ¡rios possuem funÃ§Ã£o utilitÃ¡ria ao informar e explicar ao leitor de forma clara e objetiva. SÃ£o textos informativos sem preocupaÃ§Ã£o estÃ©tica. HÃ¡ uma predominÃ¢ncia da funÃ§Ã£o referencial e da linguagem denotativa (objetiva). SÃ£o exemplos de textos nÃ£o-literÃ¡rios: notÃ­cias e reportagens jornalÃ­sticas, textos cientÃ­ficos e didÃ¡ticos, etc. Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.  Um texto pode ser codificado, sendo formado de acordo com um cÃ³digo determinado impeditivo da sua leitura direta.  Um texto tem tamanho variÃ¡vel e deve ser escr', '15 desenhos antigos: Qual deles marcaram a sua infÃ¢ncia?', 'Tuane Ronchi', '2019-11-29', 28, 1, 1),
(' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.  Um texto pode ser codificado, sendo formado de acordo com um cÃ³digo determinado impeditivo da sua leitura direta.  Um texto tem tamanho variÃ¡vel e deve ser escrito com coesÃ£o e coerÃªncia. Pode ser classificado como literÃ¡rio e nÃ£o-literÃ¡rio.  Os textos literÃ¡rios apresentam uma funÃ§Ã£o estÃ©tica. Geralmente sÃ£o escritos em linguagem expressiva e poÃ©tica, com o objetivo de atrair o interesse e emocionar o leitor. O autor segue um determinado estilo e usa as palavras de forma harmoniosa para expressar as suas ideias. HÃ¡ uma predominÃ¢ncia da funÃ§Ã£o poÃ©tica e da linguagem conotativa (subjetiva). SÃ£o exemplos de textos literÃ¡rios: romances, poesias, contos, novelas, textos sagrados, etc.  Os textos nÃ£o-literÃ¡rios possuem funÃ§Ã£o utilitÃ¡ria ao informar e explicar ao leitor de forma clara e objetiva. SÃ£o textos informativos sem preocupaÃ§Ã£o estÃ©tica. HÃ¡ uma predominÃ¢ncia da funÃ§Ã£o referencial e da linguagem denotativa (objetiva). SÃ£o exemplos de textos nÃ£o-literÃ¡rios: notÃ­cias e reportagens jornalÃ­sticas, textos cientÃ­ficos e didÃ¡ticos, etc. Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.  Um texto pode ser codificado, sendo formado de acordo com um cÃ³digo determinado impeditivo da sua leitura direta.  Um texto tem tamanho variÃ¡vel e deve ser escr', '3 paÃ­ses que qualquer pessoa pode conhecer', 'Clara Souza', '2019-11-29', 29, 1, 1),
(' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.  Um texto pode ser codificado, sendo formado de acordo com um cÃ³digo determinado impeditivo da sua leitura direta.  Um texto tem tamanho variÃ¡vel e deve ser escrito com coesÃ£o e coerÃªncia. Pode ser classificado como literÃ¡rio e nÃ£o-literÃ¡rio.  Os textos literÃ¡rios apresentam uma funÃ§Ã£o estÃ©tica. Geralmente sÃ£o escritos em linguagem expressiva e poÃ©tica, com o objetivo de atrair o interesse e emocionar o leitor. O autor segue um determinado estilo e usa as palavras de forma harmoniosa para expressar as suas ideias. HÃ¡ uma predominÃ¢ncia da funÃ§Ã£o poÃ©tica e da linguagem conotativa (subjetiva). SÃ£o exemplos de textos literÃ¡rios: romances, poesias, contos, novelas, textos sagrados, etc.  Os textos nÃ£o-literÃ¡rios possuem funÃ§Ã£o utilitÃ¡ria ao informar e explicar ao leitor de forma clara e objetiva. SÃ£o textos informativos sem preocupaÃ§Ã£o estÃ©tica. HÃ¡ uma predominÃ¢ncia da funÃ§Ã£o referencial e da linguagem denotativa (objetiva). SÃ£o exemplos de textos nÃ£o-literÃ¡rios: notÃ­cias e reportagens jornalÃ­sticas, textos cientÃ­ficos e didÃ¡ticos, etc. Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.  Um texto pode ser codificado, sendo formado de acordo com um cÃ³digo determinado impeditivo da sua leitura direta.  Um texto tem tamanho variÃ¡vel e deve ser escr', '10 maneiras de superar o fim de um relacionamento', 'Laryssa Sarti', '2019-11-29', 30, 1, 1),
(' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.  Um texto pode ser codificado, sendo formado de acordo com um cÃ³digo determinado impeditivo da sua leitura direta.  Um texto tem tamanho variÃ¡vel e deve ser escrito com coesÃ£o e coerÃªncia. Pode ser classificado como literÃ¡rio e nÃ£o-literÃ¡rio.  Os textos literÃ¡rios apresentam uma funÃ§Ã£o estÃ©tica. Geralmente sÃ£o escritos em linguagem expressiva e poÃ©tica, com o objetivo de atrair o interesse e emocionar o leitor. O autor segue um determinado estilo e usa as palavras de forma harmoniosa para expressar as suas ideias. HÃ¡ uma predominÃ¢ncia da funÃ§Ã£o poÃ©tica e da linguagem conotativa (subjetiva). SÃ£o exemplos de textos literÃ¡rios: romances, poesias, contos, novelas, textos sagrados, etc.  Os textos nÃ£o-literÃ¡rios possuem funÃ§Ã£o utilitÃ¡ria ao informar e explicar ao leitor de forma clara e objetiva. SÃ£o textos informativos sem preocupaÃ§Ã£o estÃ©tica. HÃ¡ uma predominÃ¢ncia da funÃ§Ã£o referencial e da linguagem denotativa (objetiva). SÃ£o exemplos de textos nÃ£o-literÃ¡rios: notÃ­cias e reportagens jornalÃ­sticas, textos cientÃ­ficos e didÃ¡ticos, etc. Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.  Um texto pode ser codificado, sendo formado de acordo com um cÃ³digo determinado impeditivo da sua leitura direta.  Um texto tem tamanho variÃ¡vel e deve ser escr', 'Como criar um currÃ­culo que se destaque em qualquer entrevista de emprego', 'Tuane Ronchi', '2019-11-27', 31, 1, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `categoria`
--

CREATE TABLE `categoria` (
  `tipo` varchar(100) CHARACTER SET utf8 NOT NULL,
  `cod_cat` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `categoria`
--

INSERT INTO `categoria` (`tipo`, `cod_cat`) VALUES
('lazer', 1),
('fisica', 2),
('psicologica', 3);

-- --------------------------------------------------------

--
-- Estrutura para tabela `coment_art`
--

CREATE TABLE `coment_art` (
  `cd_id_user_comart` int(3) DEFAULT NULL,
  `cd_cod_arti_comart` int(3) DEFAULT NULL,
  `comentario` varchar(250) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `coment_art`
--

INSERT INTO `coment_art` (`cd_id_user_comart`, `cd_cod_arti_comart`, `comentario`) VALUES
(49, 20, 'Muito bom esse artigo!'),
(49, 21, 'Adorei.'),
(49, 22, 'Maravilhoso...'),
(49, 23, 'SHOW!'),
(49, 24, 'Me ajudou muito.'),
(49, 25, 'Adorei.'),
(49, 26, 'Achei bom...'),
(49, 27, 'Adorei mesmo.'),
(49, 28, 'Ai muito bom!'),
(49, 29, 'Me ajudou muito...'),
(49, 30, 'Nossa Ã³timo.'),
(49, 31, ' Adorei...'),
(50, 20, 'Muito bem escrito..'),
(50, 22, 'Muito bem escrito..'),
(50, 23, 'Muito bem escrito..'),
(50, 25, 'Muito bem escrito..'),
(50, 26, 'Muito bem escrito..'),
(50, 28, 'Muito bem escrito..'),
(50, 29, 'Muito bem escrito..'),
(50, 31, 'Muito bem escrito..'),
(51, 20, 'NÃ£o gostei!'),
(51, 22, 'NÃ£o gostei!'),
(51, 23, 'NÃ£o gostei!'),
(51, 25, 'Muito bom!'),
(51, 24, 'Muito bom!'),
(51, 26, 'Muito bom!'),
(51, 27, 'NÃ£o gostei!'),
(51, 28, 'Muito bom!'),
(51, 30, 'Muito bom!');

-- --------------------------------------------------------

--
-- Estrutura para tabela `coment_cuid`
--

CREATE TABLE `coment_cuid` (
  `cd_id_ido_coment` int(3) DEFAULT NULL,
  `cd_id_cuid_coment` int(3) DEFAULT NULL,
  `comentario` varchar(250) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `coment_cuid`
--

INSERT INTO `coment_cuid` (`cd_id_ido_coment`, `cd_id_cuid_coment`, `comentario`) VALUES
(24, 20, 'Me ajudou muito! Muito cuidadoso.'),
(24, 21, 'Me ajudou muito! Muito cuidadoso.'),
(24, 22, 'Me ajudou muito! Muito cuidadoso.'),
(24, 23, 'Me ajudou muito! Muito cuidadoso.'),
(24, 24, 'Me ajudou muito! Muito cuidadoso.'),
(24, 25, 'Me ajudou muito! Muito cuidadoso.'),
(24, 26, 'Me ajudou muito! Muito cuidadoso.'),
(24, 27, 'Me ajudou muito! Muito cuidadoso.'),
(24, 28, 'Me ajudou muito! Muito cuidadoso.'),
(24, 29, 'Me ajudou muito! Muito cuidadoso.'),
(24, 30, 'Me ajudou muito! Muito cuidadoso.'),
(24, 31, 'Me ajudou muito! Muito cuidadoso.'),
(25, 20, 'Excelente!'),
(25, 21, 'Excelente!'),
(25, 22, 'Excelente!'),
(25, 23, 'Excelente!'),
(25, 25, ' Excelente!'),
(25, 30, 'Excelente!'),
(25, 28, 'Excelente!'),
(25, 31, 'Excelente!'),
(26, 20, 'Muito bom!'),
(26, 21, 'NÃ£o gostei do serviÃ§o.'),
(26, 23, 'NÃ£o gostei do serviÃ§o.'),
(26, 25, 'NÃ£o gostei do serviÃ§o.'),
(26, 30, 'NÃ£o gostei do serviÃ§o.'),
(26, 28, 'Muito bom!'),
(26, 31, 'NÃ£o gostei do serviÃ§o.');

-- --------------------------------------------------------

--
-- Estrutura para tabela `coment_inst`
--

CREATE TABLE `coment_inst` (
  `cd_cod_cominst` int(3) DEFAULT NULL,
  `cd_cod_ido_cominst` int(3) NOT NULL,
  `comentario` varchar(250) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `coment_inst`
--

INSERT INTO `coment_inst` (`cd_cod_cominst`, `cd_cod_ido_cominst`, `comentario`) VALUES
(10, 24, 'Muito confortÃ¡vel, com Ã³timas cuidadoras.'),
(11, 24, 'Muito confortÃ¡vel, com Ã³timas cuidadoras'),
(12, 24, 'Muito confortÃ¡vel, com Ã³timas cuidadoras'),
(13, 24, 'Muito confortÃ¡vel, com Ã³timas cuidadoras'),
(14, 24, 'Muito confortÃ¡vel, com Ã³timas cuidadoras'),
(15, 24, 'Muito confortÃ¡vel, com Ã³timas cuidadoras'),
(16, 24, 'Muito confortÃ¡vel, com Ã³timas cuidadoras'),
(17, 24, 'Muito confortÃ¡vel, com Ã³timas cuidadoras'),
(18, 24, 'Muito confortÃ¡vel, com Ã³timas cuidadoras'),
(10, 25, 'Excelente!'),
(11, 25, 'Excelente!'),
(12, 25, 'Excelente!'),
(14, 25, 'Excelente!'),
(16, 25, 'Excelente!'),
(18, 25, 'Excelente!'),
(10, 26, 'NÃ£o gostei do serviÃ§o.'),
(11, 26, 'Amei!'),
(13, 26, 'NÃ£o gostei do serviÃ§o.'),
(14, 26, 'Muito bom...'),
(17, 26, 'Adorei!'),
(18, 26, 'NÃ£o gostei do serviÃ§o.'),
(16, 26, 'NÃ£o gostei do serviÃ§o.');

-- --------------------------------------------------------

--
-- Estrutura para tabela `cuidador`
--

CREATE TABLE `cuidador` (
  `estado` varchar(2) CHARACTER SET utf8 NOT NULL,
  `cidade` varchar(100) CHARACTER SET utf16 NOT NULL,
  `texto` varchar(700) CHARACTER SET utf8 NOT NULL,
  `valor` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `id_cuid` int(3) NOT NULL,
  `cd_id_user` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `cuidador`
--

INSERT INTO `cuidador` (`estado`, `cidade`, `texto`, `valor`, `id_cuid`, `cd_id_user`) VALUES
('SC', 'Joinville', ' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.', 'R$2.000 (mÃªs)', 20, 37),
('SC', 'ItajaÃ­', ' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.', 'R$3.500 (mÃªs)', 21, 38),
('GO', 'GoiÃ¢nia', ' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.', 'R$200 (dia)', 22, 39),
('SP', 'SÃ£o Paulo', ' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.', 'R$ 25 (hora)', 23, 40),
('SC', 'SÃ£o Paulo', ' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.', 'R$ 80 (hora)', 24, 41),
('SP', 'Campo Limpo Paulista', ' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.', 'R$ 400 (semanal)', 25, 42),
('SC', 'Canoas', ' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.', 'R$ 1.500 (mÃªs)', 26, 43),
('SP', 'SÃ£o Bernardo do Campo', ' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.', 'R$ 500 (semanal)', 27, 44),
('PR', 'Ponta Grossa', ' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.', 'R$ 600 (diÃ¡rio)', 28, 45),
('BA', 'Teixeira de Freitas', ' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.', 'R$ 500 (semanal)', 29, 46),
('RJ', 'TrÃªs Rios', ' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.', 'R$ 400 (diÃ¡ria)', 30, 47),
('SP', 'Francisco Morato', ' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.', 'R$ 1.500 (semanal)', 31, 48);

-- --------------------------------------------------------

--
-- Estrutura para tabela `filtro`
--

CREATE TABLE `filtro` (
  `cod_filtro` int(1) NOT NULL,
  `tipo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `filtro`
--

INSERT INTO `filtro` (`cod_filtro`, `tipo`) VALUES
(1, 'idoso'),
(2, 'cuidador');

-- --------------------------------------------------------

--
-- Estrutura para tabela `idoso`
--

CREATE TABLE `idoso` (
  `cidade` varchar(100) CHARACTER SET utf8 NOT NULL,
  `estado` varchar(2) CHARACTER SET utf8 NOT NULL,
  `id_ido` int(3) NOT NULL,
  `cd_id_user` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `idoso`
--

INSERT INTO `idoso` (`cidade`, `estado`, `id_ido`, `cd_id_user`) VALUES
('Joinville', 'SC', 16, 15),
('São José dos Pinhais', 'PR', 17, 16),
('São Paulo', 'SP', 18, 17),
('Floripa', 'SC', 19, 19),
('SÃ£o Paulo', 'SP', 22, 35),
('Joinville', 'SC', 23, 36),
('Joinville', 'SC', 24, 49),
('Guarulhos', 'SP', 25, 50),
('TubarÃ£o', 'SC', 26, 51);

-- --------------------------------------------------------

--
-- Estrutura para tabela `imagem_art`
--

CREATE TABLE `imagem_art` (
  `cd_cod_art` int(3) DEFAULT NULL,
  `img` varchar(500) CHARACTER SET utf8 DEFAULT NULL,
  `cod_img_art` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `Instituicoes`
--

CREATE TABLE `Instituicoes` (
  `tel` varchar(14) CHARACTER SET utf8 NOT NULL,
  `texto` varchar(700) CHARACTER SET utf8 NOT NULL,
  `cidade` varchar(100) CHARACTER SET utf8 NOT NULL,
  `nome` varchar(100) CHARACTER SET utf8 NOT NULL,
  `rua` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(100) CHARACTER SET utf8 NOT NULL,
  `estado` varchar(2) CHARACTER SET utf8 NOT NULL,
  `num_ende` int(4) DEFAULT NULL,
  `cod_inst` int(3) NOT NULL,
  `img` varchar(500) CHARACTER SET utf8 DEFAULT NULL,
  `bairro` varchar(250) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `Instituicoes`
--

INSERT INTO `Instituicoes` (`tel`, `texto`, `cidade`, `nome`, `rua`, `email`, `estado`, `num_ende`, `cod_inst`, `img`, `bairro`) VALUES
('(47)53656-5656', ' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.', 'Joinville', 'Casa de Repouso Anjo Gabriel', 'Rua Max Lepper', 'repouso.gabriel@gmail.com', 'SC', 136, 10, 'null', 'Costa e SIlva'),
('(47)56356-5655', ' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.', 'Araquari', 'Casa De Repouso Lar Cida Moaes', 'Rua Presidente EpitÃ¡cio Pessoa', 'cida.moaes@gmail.com', 'SC', 635, 11, 'null', 'Porto Grande'),
('(11)53636-8555', ' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.', 'SÃ£o Caetano do Sul', 'Casa de Repouso Novo Horizonte', 'EpitÃ¡cio Pessoa', 'repouso.horizonte@gmail.com', 'SP', 136, 12, 'null', 'Boa Vista'),
('(47)55855-8558', ' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.', 'FlorianÃ³polis ', 'Lar Aconchego Casa De Repouso', 'Frederico Agostin', 'aconchego.repouso@gmail.com', 'SC', 789, 13, 'null', 'Almirante'),
('(45)56685-4589', ' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.', 'Curitiba', 'Lar de Idosos Dona Maria', 'Adolfo Neymer', 'dona.maria@gmail.com', 'PR', 456, 14, 'null', 'AmÃ©rica'),
('(45)45855-2855', ' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.', 'Rio de Janeiro', 'Lar Do Idoso BetÃ¢nia', 'Rua Doutor PlÃ¡cido OlÃ­mpio de Oliveira', 'idoso.betania@gmail.com', 'RJ', 123, 15, 'null', 'Barra'),
('(41)22515-4465', ' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.', 'Quilombo', 'Asilo De Quilombo', 'Rua Joao Goulart', 'asilo.quilombo@gmail.com', 'SC', 789, 16, 'null', 'Centro'),
('(47)52554-5456', ' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.', 'Lages', 'Asilo Pastor Lioses Domiciano', 'Rua Jair de Souza Passos', 'pastor.lioses@gmail.com', 'SC', 456, 17, 'null', 'PrÃ³-Morar'),
('(47)52596-5656', ' Texto Ã© um conjunto de palavras e frases encadeadas que permitem interpretaÃ§Ã£o e transmitem uma mensagem. Ã‰ qualquer obra escrita em versÃ£o original e que constitui um livro ou um documento escrito. Um texto Ã© uma unidade linguÃ­stica de extensÃ£o superior Ã  frase.  Em artes grÃ¡ficas, o texto Ã© a matÃ©ria escrita, por oposiÃ§Ã£o a toda a parte iconogrÃ¡fica (ilustraÃ§Ãµes e outros elementos). Ã‰ a parte principal do livro, revista ou periÃ³dico, constituÃ­da por composiÃ§Ã£o maciÃ§a, desprovida de tÃ­tulos, subtÃ­tulos, epÃ­grafes, fÃ³rmulas, tabelas, etc.', 'BiguaÃ§u', 'Casa Lar Anjos De Branco', 'Rua Major Livramento', 'anjos.branco@gmail.com', 'SC', 147, 18, 'null', 'Vendaval');

-- --------------------------------------------------------

--
-- Estrutura para tabela `like_art`
--

CREATE TABLE `like_art` (
  `cd_id_user_like` int(3) DEFAULT NULL,
  `cd_cod_arti_like` int(3) DEFAULT NULL,
  `ativo` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `like_art`
--

INSERT INTO `like_art` (`cd_id_user_like`, `cd_cod_arti_like`, `ativo`) VALUES
(49, 20, 1),
(49, 21, 1),
(49, 22, 1),
(49, 23, 1),
(49, 24, 1),
(49, 25, 1),
(49, 26, 1),
(49, 27, 1),
(49, 28, 1),
(49, 29, 1),
(49, 30, 1),
(49, 31, 1),
(50, 20, 1),
(50, 22, 1),
(50, 23, 1),
(50, 25, 1),
(50, 26, 1),
(50, 28, 1),
(50, 29, 1),
(50, 31, 1),
(51, 25, 1),
(51, 24, 1),
(51, 26, 1),
(51, 28, 1),
(51, 30, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `maistarde_art`
--

CREATE TABLE `maistarde_art` (
  `cd_id_user_tarde` int(3) DEFAULT NULL,
  `cd_cod_arti_tarde` int(3) DEFAULT NULL,
  `ativo` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `maistarde_art`
--

INSERT INTO `maistarde_art` (`cd_id_user_tarde`, `cd_cod_arti_tarde`, `ativo`) VALUES
(36, 26, 1),
(36, 29, 1),
(36, 21, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `maistarde_cuid`
--

CREATE TABLE `maistarde_cuid` (
  `cd_id_ido_tarde` int(3) DEFAULT NULL,
  `cd_id_cuid_tarde` int(3) DEFAULT NULL,
  `ativo` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `maistarde_cuid`
--

INSERT INTO `maistarde_cuid` (`cd_id_ido_tarde`, `cd_id_cuid_tarde`, `ativo`) VALUES
(23, 21, 1),
(23, 24, 1),
(23, 23, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `maistarde_inst`
--

CREATE TABLE `maistarde_inst` (
  `cd_cod_tarinst` int(3) DEFAULT NULL,
  `cd_cod_ido_tarinst` int(3) DEFAULT NULL,
  `ativo` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `maistarde_inst`
--

INSERT INTO `maistarde_inst` (`cd_cod_tarinst`, `cd_cod_ido_tarinst`, `ativo`) VALUES
(14, 23, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `nota_cuid`
--

CREATE TABLE `nota_cuid` (
  `cd_id_ido_nota` int(3) DEFAULT NULL,
  `cd_id_cuid_nota` int(3) DEFAULT NULL,
  `nota` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `nota_cuid`
--

INSERT INTO `nota_cuid` (`cd_id_ido_nota`, `cd_id_cuid_nota`, `nota`) VALUES
(24, 20, 1),
(24, 21, 1),
(24, 22, 1),
(24, 23, 1),
(24, 24, 1),
(24, 25, 1),
(24, 26, 1),
(24, 27, 1),
(24, 28, 1),
(24, 29, 1),
(24, 30, 1),
(24, 31, 1),
(25, 20, 1),
(25, 21, 1),
(25, 22, 1),
(25, 23, 1),
(25, 25, 1),
(25, 30, 1),
(25, 28, 1),
(25, 31, 1),
(26, 20, 1),
(26, 28, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `nota_inst`
--

CREATE TABLE `nota_inst` (
  `cd_cod_notinst` int(3) DEFAULT NULL,
  `cd_cod_ido_notinst` int(3) DEFAULT NULL,
  `nota` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `nota_inst`
--

INSERT INTO `nota_inst` (`cd_cod_notinst`, `cd_cod_ido_notinst`, `nota`) VALUES
(10, 24, 1),
(11, 24, 1),
(12, 24, 1),
(13, 24, 1),
(14, 24, 1),
(15, 24, 1),
(16, 24, 1),
(17, 24, 1),
(18, 24, 1),
(10, 25, 1),
(11, 25, 1),
(12, 25, 1),
(14, 25, 1),
(16, 25, 1),
(18, 25, 1),
(11, 26, 1),
(14, 26, 1),
(17, 26, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tipo_user`
--

CREATE TABLE `tipo_user` (
  `cod_tipuser` int(1) NOT NULL,
  `tipo` varchar(100) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `tipo_user`
--

INSERT INTO `tipo_user` (`cod_tipuser`, `tipo`) VALUES
(1, 'admin'),
(2, 'idoso'),
(3, 'cuidador');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario`
--

CREATE TABLE `usuario` (
  `img` varchar(500) CHARACTER SET utf8 DEFAULT NULL,
  `id_user` int(3) NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 NOT NULL,
  `tel` varchar(15) CHARACTER SET utf8 NOT NULL,
  `nome` varchar(50) CHARACTER SET utf8 NOT NULL,
  `senha` varchar(50) CHARACTER SET utf8 NOT NULL,
  `cd_cod_tipuser` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `usuario`
--

INSERT INTO `usuario` (`img`, `id_user`, `email`, `tel`, `nome`, `senha`, `cd_cod_tipuser`) VALUES
(NULL, 15, 'teresinha.marceka@gmail.com', '(67)35221-3231', 'Teresinha Simone Marcela Peixoto', '123TETE', 2),
(NULL, 16, 'levi.geraldo@gmail.com', '(67)58747-7232', 'Levi Geraldo Peixoto', '123levi', 2),
(NULL, 17, 'rosa.eduarda@gmail.com', '(67)55416-6323', 'Rosa Eduarda', '123rosa', 2),
(NULL, 19, 'marlene.aparecida@gmail.com', '(47)25129-4764', 'Marlene Brenda Aparecida', '123marlene', 2),
(NULL, 21, 'laryssa.jungton@gmail.com', '(47)99735-1812', 'Laryssa Jungton Sarti', 'admin', 1),
(NULL, 22, 'tuaneronchiwork@gmail.com', '(47)99252-8509', 'Tuane Ronchi', 'admin', 1),
(NULL, 23, 'clarasouzadejesus16@gmail.com', '(47)98461-4566', 'Clara SOuza de Jesus', 'admin', 1),
(NULL, 35, 'dogao_carlao@gmail.com', '(47)56987-4569', 'Roberth Carlos', '123dogui', 2),
(NULL, 36, 'teste@gmail.com', '(47)997351814', 'Teste', 'teste', 2),
(NULL, 37, 'martinez@gmail.com', '(47)55445-4564', 'Maureen A. Martinez', '123', 3),
(NULL, 38, 'shirley@gmail.com', '(47)55544-4857', 'Shirley J. Martinez', '123', 3),
(NULL, 39, 'dean@gmail.com', '(47)26565-8648', 'Dean L. Mucci', '123', 3),
(NULL, 40, 'james@gmail.com', '(46)56586-8486', 'James J. Henderson', '123', 3),
(NULL, 41, 'edward@gmail.com', '(47)49696-8867', 'Edward G. Ross', '123', 3),
(NULL, 42, 'matheus.castro@gmail.com', '(54)78548-7487', 'Matheus Castro Fernandes', '123', 3),
(NULL, 43, 'joao.rodrigues@gmail.com', '(47)54867-7487', 'JoÃ£o Rodrigues Almeida', '123', 3),
(NULL, 44, 'julieta@gmail.com', '(36)55595-6698', 'Julieta Martins', '123', 3),
(NULL, 45, 'isabella.cardoso@gmail.com', '(85)78787-8784', 'Isabella Cardoso Almeida', '123', 3),
(NULL, 46, 'julia.correia@gmail.com', '(45)56554-5556', 'Julia Correia Oliveira', '123', 3),
(NULL, 47, 'cunha.isabella@gmail.com', '(12)35655-6589', 'Isabella Goncalves Cunha', '123', 3),
(NULL, 48, 'gomes.caio@gmail.com', '(54)44545-7487', 'Caio Gomes Oliveira', '123', 3),
('', 49, 'user@gmail.com', '(47)85968-5568', 'Daniel Lima Carvalho', '123', 2),
('', 50, 'user1@gmail.com', '(47)58285-2858', 'Diego Castro Azevedo', '123', 2),
('', 51, 'user2@gmail.com', '(47)68598-8989', 'Julieta Sousa Alves', '123', 2);

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `artigo`
--
ALTER TABLE `artigo`
  ADD PRIMARY KEY (`cod_arti`),
  ADD KEY `cd_cod_filtro` (`cd_cod_filtro`),
  ADD KEY `cd_cod_cat` (`cd_cod_cat`);

--
-- Índices de tabela `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`cod_cat`);

--
-- Índices de tabela `coment_art`
--
ALTER TABLE `coment_art`
  ADD KEY `cd_id_user` (`cd_id_user_comart`),
  ADD KEY `cd_cod_arti` (`cd_cod_arti_comart`);

--
-- Índices de tabela `coment_cuid`
--
ALTER TABLE `coment_cuid`
  ADD KEY `cd_id_ido` (`cd_id_ido_coment`),
  ADD KEY `cd_id_cuid` (`cd_id_cuid_coment`);

--
-- Índices de tabela `coment_inst`
--
ALTER TABLE `coment_inst`
  ADD KEY `cd_cod_inst` (`cd_cod_cominst`),
  ADD KEY `cd_cod_ido` (`cd_cod_ido_cominst`);

--
-- Índices de tabela `cuidador`
--
ALTER TABLE `cuidador`
  ADD PRIMARY KEY (`id_cuid`),
  ADD KEY `cd_id_user` (`cd_id_user`);

--
-- Índices de tabela `filtro`
--
ALTER TABLE `filtro`
  ADD PRIMARY KEY (`cod_filtro`);

--
-- Índices de tabela `idoso`
--
ALTER TABLE `idoso`
  ADD PRIMARY KEY (`id_ido`),
  ADD KEY `cd_id_user` (`cd_id_user`);

--
-- Índices de tabela `imagem_art`
--
ALTER TABLE `imagem_art`
  ADD PRIMARY KEY (`cod_img_art`),
  ADD KEY `cd_cod_art` (`cd_cod_art`);

--
-- Índices de tabela `Instituicoes`
--
ALTER TABLE `Instituicoes`
  ADD PRIMARY KEY (`cod_inst`);

--
-- Índices de tabela `like_art`
--
ALTER TABLE `like_art`
  ADD KEY `cd_id_user` (`cd_id_user_like`),
  ADD KEY `cd_cod_arti` (`cd_cod_arti_like`);

--
-- Índices de tabela `maistarde_art`
--
ALTER TABLE `maistarde_art`
  ADD KEY `cd_id_user` (`cd_id_user_tarde`),
  ADD KEY `cd_cod_arti` (`cd_cod_arti_tarde`);

--
-- Índices de tabela `maistarde_cuid`
--
ALTER TABLE `maistarde_cuid`
  ADD KEY `cd_id_ido` (`cd_id_ido_tarde`),
  ADD KEY `cd_id_cuid` (`cd_id_cuid_tarde`);

--
-- Índices de tabela `maistarde_inst`
--
ALTER TABLE `maistarde_inst`
  ADD KEY `cd_cod_inst` (`cd_cod_tarinst`),
  ADD KEY `cd_cod_ido` (`cd_cod_ido_tarinst`);

--
-- Índices de tabela `nota_cuid`
--
ALTER TABLE `nota_cuid`
  ADD KEY `cd_id_ido` (`cd_id_ido_nota`),
  ADD KEY `cd_id_cuid` (`cd_id_cuid_nota`);

--
-- Índices de tabela `nota_inst`
--
ALTER TABLE `nota_inst`
  ADD KEY `cd_cod_inst` (`cd_cod_notinst`),
  ADD KEY `cd_cod_ido` (`cd_cod_ido_notinst`);

--
-- Índices de tabela `tipo_user`
--
ALTER TABLE `tipo_user`
  ADD PRIMARY KEY (`cod_tipuser`);

--
-- Índices de tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `cd_cod_tipuser` (`cd_cod_tipuser`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `artigo`
--
ALTER TABLE `artigo`
  MODIFY `cod_arti` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT de tabela `categoria`
--
ALTER TABLE `categoria`
  MODIFY `cod_cat` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de tabela `cuidador`
--
ALTER TABLE `cuidador`
  MODIFY `id_cuid` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT de tabela `filtro`
--
ALTER TABLE `filtro`
  MODIFY `cod_filtro` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de tabela `idoso`
--
ALTER TABLE `idoso`
  MODIFY `id_ido` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT de tabela `imagem_art`
--
ALTER TABLE `imagem_art`
  MODIFY `cod_img_art` int(3) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `Instituicoes`
--
ALTER TABLE `Instituicoes`
  MODIFY `cod_inst` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT de tabela `tipo_user`
--
ALTER TABLE `tipo_user`
  MODIFY `cod_tipuser` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_user` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
--
-- Restrições para dumps de tabelas
--

--
-- Restrições para tabelas `artigo`
--
ALTER TABLE `artigo`
  ADD CONSTRAINT `artigo_ibfk_1` FOREIGN KEY (`cd_cod_filtro`) REFERENCES `filtro` (`cod_filtro`),
  ADD CONSTRAINT `artigo_ibfk_2` FOREIGN KEY (`cd_cod_cat`) REFERENCES `categoria` (`cod_cat`);

--
-- Restrições para tabelas `coment_art`
--
ALTER TABLE `coment_art`
  ADD CONSTRAINT `coment_art_ibfk_1` FOREIGN KEY (`cd_id_user_comart`) REFERENCES `usuario` (`id_user`),
  ADD CONSTRAINT `coment_art_ibfk_2` FOREIGN KEY (`cd_cod_arti_comart`) REFERENCES `artigo` (`cod_arti`);

--
-- Restrições para tabelas `coment_cuid`
--
ALTER TABLE `coment_cuid`
  ADD CONSTRAINT `coment_cuid_ibfk_1` FOREIGN KEY (`cd_id_ido_coment`) REFERENCES `idoso` (`id_ido`),
  ADD CONSTRAINT `coment_cuid_ibfk_2` FOREIGN KEY (`cd_id_cuid_coment`) REFERENCES `cuidador` (`id_cuid`);

--
-- Restrições para tabelas `coment_inst`
--
ALTER TABLE `coment_inst`
  ADD CONSTRAINT `coment_inst_ibfk_1` FOREIGN KEY (`cd_cod_cominst`) REFERENCES `Instituicoes` (`cod_inst`),
  ADD CONSTRAINT `coment_inst_ibfk_2` FOREIGN KEY (`cd_cod_ido_cominst`) REFERENCES `idoso` (`id_ido`);

--
-- Restrições para tabelas `cuidador`
--
ALTER TABLE `cuidador`
  ADD CONSTRAINT `cuidador_ibfk_1` FOREIGN KEY (`cd_id_user`) REFERENCES `usuario` (`id_user`);

--
-- Restrições para tabelas `idoso`
--
ALTER TABLE `idoso`
  ADD CONSTRAINT `idoso_ibfk_1` FOREIGN KEY (`cd_id_user`) REFERENCES `usuario` (`id_user`);

--
-- Restrições para tabelas `imagem_art`
--
ALTER TABLE `imagem_art`
  ADD CONSTRAINT `imagem_art_ibfk_1` FOREIGN KEY (`cd_cod_art`) REFERENCES `artigo` (`cod_arti`);

--
-- Restrições para tabelas `like_art`
--
ALTER TABLE `like_art`
  ADD CONSTRAINT `like_art_ibfk_1` FOREIGN KEY (`cd_id_user_like`) REFERENCES `usuario` (`id_user`),
  ADD CONSTRAINT `like_art_ibfk_2` FOREIGN KEY (`cd_cod_arti_like`) REFERENCES `artigo` (`cod_arti`);

--
-- Restrições para tabelas `maistarde_art`
--
ALTER TABLE `maistarde_art`
  ADD CONSTRAINT `maistarde_art_ibfk_1` FOREIGN KEY (`cd_id_user_tarde`) REFERENCES `usuario` (`id_user`),
  ADD CONSTRAINT `maistarde_art_ibfk_2` FOREIGN KEY (`cd_cod_arti_tarde`) REFERENCES `artigo` (`cod_arti`);

--
-- Restrições para tabelas `maistarde_cuid`
--
ALTER TABLE `maistarde_cuid`
  ADD CONSTRAINT `maistarde_cuid_ibfk_1` FOREIGN KEY (`cd_id_ido_tarde`) REFERENCES `idoso` (`id_ido`),
  ADD CONSTRAINT `maistarde_cuid_ibfk_2` FOREIGN KEY (`cd_id_cuid_tarde`) REFERENCES `cuidador` (`id_cuid`);

--
-- Restrições para tabelas `maistarde_inst`
--
ALTER TABLE `maistarde_inst`
  ADD CONSTRAINT `maistarde_inst_ibfk_1` FOREIGN KEY (`cd_cod_tarinst`) REFERENCES `Instituicoes` (`cod_inst`),
  ADD CONSTRAINT `maistarde_inst_ibfk_2` FOREIGN KEY (`cd_cod_ido_tarinst`) REFERENCES `idoso` (`id_ido`);

--
-- Restrições para tabelas `nota_cuid`
--
ALTER TABLE `nota_cuid`
  ADD CONSTRAINT `nota_cuid_ibfk_1` FOREIGN KEY (`cd_id_ido_nota`) REFERENCES `idoso` (`id_ido`),
  ADD CONSTRAINT `nota_cuid_ibfk_2` FOREIGN KEY (`cd_id_cuid_nota`) REFERENCES `cuidador` (`id_cuid`);

--
-- Restrições para tabelas `nota_inst`
--
ALTER TABLE `nota_inst`
  ADD CONSTRAINT `nota_inst_ibfk_1` FOREIGN KEY (`cd_cod_notinst`) REFERENCES `Instituicoes` (`cod_inst`),
  ADD CONSTRAINT `nota_inst_ibfk_2` FOREIGN KEY (`cd_cod_ido_notinst`) REFERENCES `idoso` (`id_ido`);

--
-- Restrições para tabelas `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`cd_cod_tipuser`) REFERENCES `tipo_user` (`cod_tipuser`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
