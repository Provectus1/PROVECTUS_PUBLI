 <?php 
     
require_once __DIR__."/../conexao/Connection.php";

class Usuario_idoso{

    //ATRIBUTOS DA CLASSE
    public $nome;
    public $email;
    public $senha;
    public $cidade;
    public $estado;
    public $tel; 
    public $cd_cod_tipuser; //1 admin, 2 idoso e 3 cuidador

    public $conexao;

    //COMPORTAMENTOS
    public function __construct(){
        $this->cd_cod_tipuser = 2;
        $conexao_objeto = new Connection();

        //o atributo $this->conexao agora sabe como se
        // comunicar com o banco de dados
        $this->conexao = $conexao_objeto->getConnection();
    }

    public function exibe (){
        echo "usuario {$this->nome} foi criado com o tipo {$this->cd_cod_tipuser} e id {$this->id_user} \n";
    }

    public function todos(){
        return $this->conexao->query("select * from usuario")->fetchAll(PDO::FETCH_CLASS, 'Usuario');
    }


    public function getUserById($id_user){
        $total= array();
        $user = $this->conexao->query("select * from usuario where id_user = {$id_user}")->fetch(PDO::FETCH_ASSOC);
        $user2 = $this->conexao->query("select * from idoso where cd_id_user = {$id_user}")->fetch(PDO::FETCH_ASSOC);
        $total[] = $user;
        $total[] = $user2;
        return $total;
    }



    public function salvar_idoso($nome, $email, $senha,$tel,$cidade,$estado){
        $sql1="select * from usuario where email = '{$email}'";
        //echo $sql;
        $verifica = $this->conexao->query($sql1)->fetch(PDO::FETCH_ASSOC);

        if($verifica != null){
            return true;
        }else{

        $sql = "insert into usuario(email, tel, nome, senha,cd_cod_tipuser) values ('$email', '$tel','$nome','$senha', 2)";
        $this->conexao->exec($sql);

        $last_id = $this->conexao->lastInsertId();
        
        $sql2 = "insert into idoso(cidade,estado,cd_id_user) values ('$cidade','$estado', '$last_id')";
        $this->conexao->exec($sql2);

            return false;
        }
        
    }

    public function update_idoso($id_user, $nome, $email, $senha, $tel, $cidade,$estado){

        $sql = "update usuario set nome='$nome', email='$email', senha='$senha', tel='$tel' WHERE  id_user=$id_user";
        $this->conexao->exec($sql);
        
        $sql2 = "update idoso set cidade='$cidade', estado='$estado' WHERE cd_id_user=$id_user";
        $this->conexao->exec($sql2);
    }

    public function delete_idoso($id_user,$id_ido){


        $sql = "delete from coment_cuid where cd_id_ido_coment=$id_ido";
        $this->conexao->exec($sql);


        $sql1 = "delete from coment_inst where cd_cod_ido_cominst=$id_ido";
        $this->conexao->exec($sql1);


        $sql2 = "delete from maistarde_cuid where cd_id_ido_tarde=$id_ido";
        $this->conexao->exec($sql2);

        $sql3 = "delete from maistarde_inst where cd_cod_ido_tarinst=$id_ido";
        $this->conexao->exec($sql3);

        $sql4 = "delete from nota_cuid where cd_id_ido_nota=$id_ido";
        $this->conexao->exec($sql4);

        $sql5 = "delete from nota_inst where cd_cod_ido_notinst=$id_ido";
        $this->conexao->exec($sql5);


        $sql6 = "delete from maistarde_art where cd_id_user_tarde=$id_user";
        $this->conexao->exec($sql6);


        $sql7 = "delete from like_art where cd_id_user_like=$id_user";
        $this->conexao->exec($sql7);


        $sql8 = "delete from coment_art where cd_id_user_comart=$id_user";
        $this->conexao->exec($sql8);

        $sql9 = "delete from idoso where cd_id_user=$id_user";
        $this->conexao->exec($sql9);

        $sql10 = "delete from usuario where id_user=$id_user";
        $this->conexao->exec($sql10);
    }

    public function loga_auto($email,$senha){
        $sql="select * from usuario where email = '{$email}' and senha = '{$senha}'";
        //echo $sql;
        $result_id = $this->conexao->query($sql)->fetch(PDO::FETCH_ASSOC);
        // echo "<pre>";
        // var_dump($result_id);
        // exit();
        //print_r($result_id);
        if($result_id != null){
            $_SESSION['logado'] = 'TRUE';
            $_SESSION['id_user'] = $result_id['id_user'];
            $_SESSION['tipo_user'] =$result_id['cd_cod_tipuser'];


            return true;
        }else{
            return false;
        }
    

    }

    //validar imagem = sempre retornar 1

    
    public function valida_imagem($foto_produto){

        if ($foto_produto['type'] == 'image/png' or $foto_produto['type'] == 'image/jpeg' ){

            if ($foto_produto['size'] > 400000000000){
                return 2; //ESCOLHA UMA IMAGEM MENOR
            }else{
                return 1; //IMAGEM VALIDA
            }

        }elseif ($foto_produto['type'] == 'image/jpg'){

            if ($foto_produto['size'] > 400000000000){
                return 2; //ESCOLHA UMA IMAGEM MENOR
            }else{
                return 1; //IMAGEM VALIDA
            }

        }elseif (empty($foto_produto['name'])){
            return 4; //SEM IMAGEM
        }else{
            $nome = explode('.', $foto_produto['name']);
            return $nome[1]; //ESCOLHA UMA IMAGEM VALIDA
        }

    }

    public function getCuidById_anuncio($id_cuid){
       $total= array();

        $info_1 = $this->conexao->query("select * from usuario where id_user = {$id_cuid}")->fetch(PDO::FETCH_ASSOC);
        $info_2 = $this->conexao->query("select * from cuidador where cd_id_user = {$id_cuid}")->fetch(PDO::FETCH_ASSOC);
        $total[] = $info_1;
        $total[] = $info_2;
        return $total;
    }

    public function coment_cuid_lista($id_cuid){
        $info_coment = $this->conexao->query("select * from coment_cuid where cd_id_cuid_coment = {$id_cuid}")->fetchAll(PDO::FETCH_ASSOC);
        return $info_coment;
    }
   
    public function getUserById_idoso($cod_ido){
       $id_user_array = $this->conexao->query("select cd_id_user from idoso where id_ido = {$cod_ido}")->fetch(PDO::FETCH_ASSOC);

       $id_user = $id_user_array['cd_id_user'];

       

        $total= array();
        $user = $this->conexao->query("select * from usuario where id_user = {$id_user}")->fetch(PDO::FETCH_ASSOC);
        $user2 = $this->conexao->query("select * from idoso where cd_id_user = {$id_user}")->fetch(PDO::FETCH_ASSOC);
        $total[] = $user;
        $total[] = $user2;
        return $total;
    }


    public function existe_like_cuid($cod_ido,$cod_cuid){
        $sql = "select * from nota_cuid where cd_id_ido_nota = {$cod_ido} and  nota =1 and cd_id_cuid_nota  = {$cod_cuid} ";
        $verifica = $this->conexao->query($sql)->fetch(PDO::FETCH_ASSOC);

        if($verifica != null){
             return true;
        
        }else{
            return false;

             
        }
        
    }

    public function descurtir_cuid($cod_ido,$cod_cuid){

     $this->conexao->query("update nota_cuid set nota='0' WHERE cd_id_ido_nota = {$cod_ido} and  cd_id_cuid_nota ={$cod_cuid} ");
        
    }

    public function curtir_cuid($cod_ido,$cod_cuid){

        $sql = "select * from nota_cuid where cd_id_ido_nota = {$cod_ido} and  cd_id_cuid_nota ={$cod_cuid} ";
        $verifica = $this->conexao->query($sql)->fetch(PDO::FETCH_ASSOC);
     
        if($verifica != null){
             $this->conexao->query("update nota_cuid set nota='1' WHERE cd_id_ido_nota = {$cod_ido} and  cd_id_cuid_nota ={$cod_cuid} ");
        
        }else{
            $this->conexao->query("insert into nota_cuid(cd_id_ido_nota, cd_id_cuid_nota, nota) values ($cod_ido,$cod_cuid,1)");

             
        }
      

    }

    public function total_likes_cuid($cod_cuid){

     $result = $this->conexao->query("select count(cd_id_ido_nota) as qtd_like from nota_cuid where cd_id_cuid_nota = {$cod_cuid} and nota =1 ")->fetch(PDO::FETCH_ASSOC);
      return $result;
        
    }


    public function lista_maistarde_inst($cod_ido){
       $result_lista_inst = $this->conexao->query("select cd_cod_tarinst from maistarde_inst where cd_cod_ido_tarinst ={$cod_ido} and ativo=1")->fetchAll(PDO::FETCH_ASSOC);
       return $result_lista_inst;

    }

    public function informacao_inst_maistarde($id_inst){
        $info = $this->conexao->query("select * from Instituicoes where cod_inst = {$id_inst}")->fetch(PDO::FETCH_ASSOC);
        return $info;
    }
   
    public function lista_maistarde_art($cod_user){
       $result_lista_art = $this->conexao->query("select cd_cod_arti_tarde from maistarde_art where cd_id_user_tarde ={$cod_user} and ativo=1")->fetchAll(PDO::FETCH_ASSOC);
       return $result_lista_art;

    }


    public function informacao_art_maistarde($id_art){
        $info = $this->conexao->query("select * from artigo where cod_arti = {$id_art}")->fetch(PDO::FETCH_ASSOC);
        return $info;
    }
    

    public function existe_tarde_cuid($cod_ido,$cod_cuid){
        $sql = "select * from maistarde_cuid where  cd_id_ido_tarde = {$cod_ido} and  cd_id_cuid_tarde ={$cod_cuid} and ativo=1";
        $verifica = $this->conexao->query($sql)->fetch(PDO::FETCH_ASSOC);

        if($verifica != null){
             return true;
        
        }else{
            return false;

             
        }
        
    }
    public function tira_tarde_cuid($cod_ido,$cod_cuid){

     $this->conexao->query("update maistarde_cuid set ativo='0' WHERE cd_id_ido_tarde = {$cod_ido} and  cd_id_cuid_tarde ={$cod_cuid}");
        
    }


    public function tarde_cuid($cod_ido,$cod_cuid){

        $sql = "select * from maistarde_cuid where  cd_id_ido_tarde = {$cod_ido} and  cd_id_cuid_tarde ={$cod_cuid}";
        $verifica = $this->conexao->query($sql)->fetch(PDO::FETCH_ASSOC);
     
        if($verifica != null){
             $this->conexao->query("update maistarde_cuid set ativo='1' WHERE cd_id_ido_tarde = {$cod_ido} and  cd_id_cuid_tarde ={$cod_cuid} ");
        
        }else{
            $this->conexao->query("insert into maistarde_cuid(cd_id_ido_tarde, cd_id_cuid_tarde, ativo) values ($cod_ido,$cod_cuid,1)");

             
        }
    }

    public function lista_maistarde_cuid($cod_ido){
       $result_lista_inst = $this->conexao->query("select cd_id_cuid_tarde from maistarde_cuid where cd_id_ido_tarde ={$cod_ido} and ativo=1")->fetchAll(PDO::FETCH_ASSOC);
       return $result_lista_inst;

    }

    public function informacao_cuid_maistarde($id_cuid){
       $total= array();

       $user1 = $this->conexao->query("select cd_id_user from cuidador where id_cuid = {$id_cuid}")->fetch(PDO::FETCH_ASSOC);
        
       $user = $this->conexao->query("select nome,img,id_user from usuario where id_user = {$user1['cd_id_user']}")->fetch(PDO::FETCH_ASSOC);
        
       $user2 = $this->conexao->query("select estado,cidade from cuidador where id_cuid = {$id_cuid}")->fetch(PDO::FETCH_ASSOC);
        
        $total[] = $user;
        $total[] = $user2;

        return $total;
    }


}