 <?php   
    
require_once __DIR__."/../conexao/Connection.php"; 
 
class Artigo{

	public $conteudo; 
	public $titulo;
	public $cidade;
	public $autor;
	public $dat;
	public $cd_cod_cat;

    public $conexao;

    public function __construct(){

        $conexao_objeto = new Connection();
        $this->conexao = $conexao_objeto->getConnection();
    }

    public function getArtigotById($id_artigo){
        $info = $this->conexao->query("select * from artigo where cod_arti = {$id_artigo}")->fetch(PDO::FETCH_ASSOC);
        return $info;
    }


    public function listar_arti($cod_categoria){
       $result_lista_arti = $this->conexao->query("select cod_arti from artigo where cd_cod_cat ={$cod_categoria}")->fetchAll(PDO::FETCH_ASSOC);
       return $result_lista_arti;
    }

    public function getId_art($titulo){
       $result_id_art = $this->conexao->query("select cod_arti from artigo where titulo = '{$titulo}'")->fetch(PDO::FETCH_ASSOC);
       return $result_id_art;
    }
    
    public function salvar_artigo($texto,$titulo,$autor,$data,$cod_filtro,$cod_cat){
        $sql1="select * from artigo where titulo = '{$titulo}'";
        //echo $sql;
        $verifica = $this->conexao->query($sql1)->fetch(PDO::FETCH_ASSOC);

        if($verifica != null){
            return true;
        
        }else{
            $sql = "insert into artigo(conteudo,titulo,autor,dat,cd_cod_filtro,cd_cod_cat) values ('$texto', '$titulo','$autor' ,'$data', $cod_filtro, $cod_cat)";
            $this->conexao->exec($sql);

            return false;
        }
        
    }
     public function update_art($texto,$titulo,$autor,$data, $id_art){

        $sql = "update artigo set conteudo= '$texto',titulo= '$titulo', autor= '$autor', dat= '$data' WHERE  cod_arti={$id_art}";
        $this->conexao->exec($sql);
        
    }

    public function deleta_art($id_art){
        $sql1 = "delete from coment_art where cd_cod_arti_comart={$id_art}";
        $this->conexao->exec($sql1);

        $sql3 = "delete from maistarde_art where cd_cod_arti_tarde={$id_art}";
        $this->conexao->exec($sql3);

        $sql5 = "delete from like_art where cd_cod_arti_like={$id_art}";
        $this->conexao->exec($sql5);

        $sql6 = "delete from artigo where cod_arti={$id_art}";
        $this->conexao->exec($sql6);

    }
   
    public function coment_art_lista($id_art){
        $info_coment = $this->conexao->query("select * from coment_art where cd_cod_arti_comart = {$id_art}")->fetchAll(PDO::FETCH_ASSOC);
        return $info_coment;
    }
    
    public function getUserById_idoso_art($cod_ido){
        $user = $this->conexao->query("select * from usuario where id_user = {$cod_ido}")->fetch(PDO::FETCH_ASSOC);
        return $user;
    }
    
    public function total_likes_art($cod_art){

     $result = $this->conexao->query("select count(cd_id_user_like) as qtd_like from like_art where cd_cod_arti_like = {$cod_art} and ativo =1 ")->fetch(PDO::FETCH_ASSOC);
      return $result;
        
    }
    
    public function existe_like_art($cod_user,$cod_art){
        $sql = "select * from like_art where cd_cod_arti_like = {$cod_art} and  ativo =1 and cd_id_user_like  = {$cod_user} ";
        $verifica = $this->conexao->query($sql)->fetch(PDO::FETCH_ASSOC);

        if($verifica != null){
             return true;
        
        }else{
            return false;

             
        }
        
    }
    
    public function descurtir_art($cod_user,$cod_art){

     $this->conexao->query("update like_art set ativo='0' WHERE cd_cod_arti_like = {$cod_art} and  cd_id_user_like  = {$cod_user}");
        
    }

    public function curtir_art($cod_user,$cod_art){

        $sql = "select * from like_art where cd_cod_arti_like = {$cod_art} and  cd_id_user_like  = {$cod_user}";
        $verifica = $this->conexao->query($sql)->fetch(PDO::FETCH_ASSOC);
     
        if($verifica != null){
             $this->conexao->query("update like_art set ativo='1' WHERE cd_cod_arti_like = {$cod_art} and  cd_id_user_like  = {$cod_user}");
        
        }else{
            $this->conexao->query("insert into like_art(cd_id_user_like, cd_cod_arti_like, ativo) values ($cod_user,$cod_art,1)");

             
        }
      

    }
    
    public function existe_tarde_art($cod_user,$cod_art){
        $sql = "select * from maistarde_art where  cd_cod_arti_tarde = {$cod_art} and  cd_id_user_tarde ={$cod_user} and ativo=1";
        $verifica = $this->conexao->query($sql)->fetch(PDO::FETCH_ASSOC);

        if($verifica != null){
             return true;
        
        }else{
            return false;

             
        }
        
    }

    public function tarde_art($cod_user,$cod_art){

        $sql = "select * from maistarde_art where  cd_cod_arti_tarde = {$cod_art} and  cd_id_user_tarde ={$cod_user}";
        $verifica = $this->conexao->query($sql)->fetch(PDO::FETCH_ASSOC);
     
        if($verifica != null){
             $this->conexao->query("update maistarde_art set ativo='1' WHERE cd_cod_arti_tarde = {$cod_art} and  cd_id_user_tarde ={$cod_user}");
        
        }else{
            $this->conexao->query("insert into maistarde_art(cd_id_user_tarde, cd_cod_arti_tarde, ativo) values ($cod_user,$cod_art,1)");

             
        }
    }

    public function tira_tarde_art($cod_user,$cod_art){

     $this->conexao->query("update maistarde_art set ativo='0' WHERE cd_cod_arti_tarde = {$cod_art} and  cd_id_user_tarde ={$cod_user}");
        
    }

}