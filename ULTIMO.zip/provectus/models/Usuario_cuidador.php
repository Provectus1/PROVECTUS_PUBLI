<?php
 

require_once __DIR__."/../conexao/Connection.php";
 
class Usuario_cuid{
 
    //ATRIBUTOS DA CLASSE
    public $nome;
    public $email;
    public $senha;
    public $cidade;
    public $estado;
    public $tel;
    public $texto;
    public $valor;
    public $cd_cod_tipuser; //1 admin, 2 idoso e 3 cuidador

    public $conexao;

    //COMPORTAMENTOS
    public function __construct(){
        $this->cd_cod_tipuser = 3;
        $conexao_objeto = new Connection();

        //o atributo $this->conexao agora sabe como se
        // comunicar com o banco de dados
        $this->conexao = $conexao_objeto->getConnection();
    }


    public function getUserById($id_user){
        $total= array();
        $user = $this->conexao->query("select * from usuario where id_user = {$id_user}")->fetch(PDO::FETCH_ASSOC);
        $user2 = $this->conexao->query("select * from cuidador where cd_id_user = {$id_user}")->fetch(PDO::FETCH_ASSOC);
        $total[] = $user;
        $total[] = $user2;
        return $total;
    }


    public function salvar_cuid($nome, $email, $senha,$tel,$cidade,$estado,$texto,$valor){
        $sql1="select * from usuario where email = '{$email}'";
        //echo $sql;
        $verifica = $this->conexao->query($sql1)->fetch(PDO::FETCH_ASSOC);

        if($verifica != null){
            return true;
        }else{

          $sql = "insert into usuario(email, tel, nome, senha,cd_cod_tipuser) values ( '$email', '$tel','$nome','$senha', 3)";
          $this->conexao->exec($sql);

          $last_id = $this->conexao->lastInsertId();
        
          $sql2 = "insert into cuidador(estado,cidade,texto,valor,cd_id_user) values ('$estado','$cidade','$texto','$valor', '$last_id')";
          $this->conexao->exec($sql2);
            
          return false;
        }
        
    }

    public function update_cuidador($id_user, $nome, $email, $senha, $tel, $cidade,$estado,$texto,$valor){

        $sql = "update usuario set nome='$nome', email='$email', senha='$senha', tel='$tel' WHERE  id_user=$id_user";
        $this->conexao->exec($sql);
        
        $sql2 = "update cuidador set cidade='$cidade', estado='$estado', texto='$texto', valor='$valor' WHERE cd_id_user=$id_user";
        $this->conexao->exec($sql2);
    }

    public function delete_cuidador($id_user,$id_cuid){

// excluir primeiro todas as tabelas que possuem chave estrangeira id_user ou id_cuid

        $sql = "delete from maistarde_cuid where cd_id_cuid_tarde=$id_cuid";
        $this->conexao->exec($sql);

        $sql2 = "delete from coment_cuid where cd_id_cuid_coment=$id_cuid";
        $this->conexao->exec($sql2);

        $sql3 = "delete from nota_cuid where cd_id_cuid_nota=$id_cuid";
        $this->conexao->exec($sql3);

        $sql4 = "delete from like_art where cd_id_user_like=$id_user";
        $this->conexao->exec($sql4);


        $sql5 = "delete from maistarde_art where cd_id_user_tarde=$id_user";
        $this->conexao->exec($sql5);

        $sql6 = "delete from coment_art where cd_id_user_comart=$id_user";
        $this->conexao->exec($sql6);

        $sql7 = "delete from cuidador where cd_id_user=$id_user";
        $this->conexao->exec($sql7);

        $sql8 = "delete from usuario where id_user=$id_user";
        $this->conexao->exec($sql8);


    }


    public function loga_auto($email,$senha){
        $sql="select * from usuario where email = '{$email}' and senha = '{$senha}'";
        //echo $sql;
        $result_id = $this->conexao->query($sql)->fetch(PDO::FETCH_ASSOC);
        // echo "<pre>";
        // var_dump($result_id);
        // exit();
        //print_r($result_id);
        if($result_id != null){
            $_SESSION['logado'] = 'TRUE';
            $_SESSION['id_user'] = $result_id['id_user'];
            $_SESSION['tipo_user'] =$result_id['cd_cod_tipuser'];


            return true;
        }else{
            return false;
        }
    }

    public function valida_imagem($foto_produto){

        if ($foto_produto['type'] == 'image/png' or $foto_produto['type'] == 'image/jpeg' ){

            if ($foto_produto['size'] > 400000000000){
                return 2; //ESCOLHA UMA IMAGEM MENOR
            }else{
                return 1; //IMAGEM VALIDA
            }

        }elseif ($foto_produto['type'] == 'image/jpg'){

            if ($foto_produto['size'] > 400000000000){
                return 2; //ESCOLHA UMA IMAGEM MENOR
            }else{
                return 1; //IMAGEM VALIDA
            }

        }elseif (empty($foto_produto['name'])){
            return 4; //SEM IMAGEM
        }else{
            $nome = explode('.', $foto_produto['name']);
            return $nome[1]; //ESCOLHA UMA IMAGEM VALIDA
        }

    }

}