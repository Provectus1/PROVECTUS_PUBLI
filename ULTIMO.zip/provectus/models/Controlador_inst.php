<?php   
   
require_once __DIR__."/../conexao/Connection.php";  

class Inst{

	public $tel; 
	public $texto;
	public $cidade;
	public $nome;
	public $rua;
	public $email;
	public $estado;
	public $bairro;
	public $num_ende;
	public $img;

    public $conexao;

    public function __construct(){

        $conexao_objeto = new Connection();
        $this->conexao = $conexao_objeto->getConnection();
    }


        public function getInstById($id_inst){
        $info = $this->conexao->query("select * from Instituicoes where cod_inst = {$id_inst}")->fetch(PDO::FETCH_ASSOC);
        return $info;
    }

    public function salvar_inst_model($tel,$texto,$cidade,$nome,$rua,$email,$estado,$num_ende,$bairro){
        $sql1="select * from Instituicoes where bairro = '{$bairro}' and nome ='{$nome}'";
        //echo $sql;
        $verifica = $this->conexao->query($sql1)->fetch(PDO::FETCH_ASSOC);

        if($verifica != null){
            return true;
        
        }else{
        	$sql = "insert into Instituicoes(tel, texto, cidade, nome, rua, email, estado, num_ende, bairro) values ('$tel', '$texto', '$cidade', '$nome', '$rua', '$email', '$estado', $num_ende, '$bairro')";
        	$this->conexao->exec($sql);

            return false;
        }
        
    }

    public function coment_inst_lista($id_inst){
        $info_coment = $this->conexao->query("select * from coment_inst where cd_cod_cominst = {$id_inst}")->fetchAll(PDO::FETCH_ASSOC);
        return $info_coment;
    }

    public function getUserById_idoso($cod_ido){
       $id_user_array = $this->conexao->query("select cd_id_user from idoso where id_ido = {$cod_ido}")->fetch(PDO::FETCH_ASSOC);

       $id_user = $id_user_array['cd_id_user'];

       

        $total= array();
        $user = $this->conexao->query("select * from usuario where id_user = {$id_user}")->fetch(PDO::FETCH_ASSOC);
        $user2 = $this->conexao->query("select * from idoso where cd_id_user = {$id_user}")->fetch(PDO::FETCH_ASSOC);
        $total[] = $user;
        $total[] = $user2;
        return $total;
    }

     public function update_inst($tel,$texto,$cidade,$nome,$rua,$email,$estado,$num_ende,$id_inst,$bairro){

        $sql = "update Instituicoes set tel='$tel',texto='$texto',cidade='$cidade',nome='$nome',rua='$rua',email='$email',estado='$estado',num_ende=$num_ende,bairro='$bairro'  WHERE  cod_inst=$id_inst";
        $this->conexao->exec($sql);
        
    }

    public function deleta_inst($id_inst){
        $sql1 = "delete from coment_inst where cd_cod_cominst=$id_inst";
        $this->conexao->exec($sql1);

        $sql3 = "delete from maistarde_inst where cd_cod_tarinst=$id_inst";
        $this->conexao->exec($sql3);

        $sql5 = "delete from nota_inst where cd_cod_notinst=$id_inst";
        $this->conexao->exec($sql5);

        $sql6 = "delete from Instituicoes where cod_inst=$id_inst";
        $this->conexao->exec($sql6);

    }
    

    public function getId_inst($nome,$bairro){
       $result_id_inst = $this->conexao->query("select cod_inst from Instituicoes where nome = '{$nome}' and bairro ='{$bairro}'")->fetch(PDO::FETCH_ASSOC);
       return $result_id_inst;
    }

    public function curtir_inst($cod_user,$cod_inst){

        $sql = "select * from nota_inst where cd_cod_notinst = {$cod_inst} and  cd_cod_ido_notinst ={$cod_user}";
        $verifica = $this->conexao->query($sql)->fetch(PDO::FETCH_ASSOC);
     
        if($verifica != null){
             $this->conexao->query("update nota_inst set nota='1' WHERE cd_cod_notinst = {$cod_inst} and  cd_cod_ido_notinst ={$cod_user} ");
        
        }else{
            $this->conexao->query("insert into nota_inst(cd_cod_notinst, cd_cod_ido_notinst, nota) values ($cod_inst,$cod_user,1)");

             
        }
      

    }
    public function existe_like($cod_user,$cod_inst){
        $sql = "select * from nota_inst where cd_cod_notinst = {$cod_inst} and  cd_cod_ido_notinst ={$cod_user} and nota =1";
        $verifica = $this->conexao->query($sql)->fetch(PDO::FETCH_ASSOC);

        if($verifica != null){
             return true;
        
        }else{
            return false;

             
        }
        
    }

    public function descurtir_inst($cod_user,$cod_inst){

     $this->conexao->query("update nota_inst set nota='0' WHERE cd_cod_notinst = {$cod_inst} and  cd_cod_ido_notinst ={$cod_user} ");
        
    }
    
    public function total_likes_inst($cod_inst){

     $result = $this->conexao->query("select count(cd_cod_ido_notinst) as qtd_like from nota_inst where cd_cod_notinst = {$cod_inst} and nota =1 ")->fetch(PDO::FETCH_ASSOC);
      return $result;
        
    }
    public function tarde_inst($cod_user,$cod_inst){

        $sql = "select * from maistarde_inst where  cd_cod_tarinst = {$cod_inst} and  cd_cod_ido_tarinst ={$cod_user}";
        $verifica = $this->conexao->query($sql)->fetch(PDO::FETCH_ASSOC);
     
        if($verifica != null){
             $this->conexao->query("update maistarde_inst set ativo='1' WHERE cd_cod_tarinst = {$cod_inst} and  cd_cod_ido_tarinst ={$cod_user} ");
        
        }else{
            $this->conexao->query("insert into maistarde_inst(cd_cod_tarinst, cd_cod_ido_tarinst, ativo) values ($cod_inst,$cod_user,1)");

             
        }
    }

    public function existe_tarde_inst($cod_user,$cod_inst){
        $sql = "select * from maistarde_inst where  cd_cod_tarinst = {$cod_inst} and  cd_cod_ido_tarinst ={$cod_user} and ativo=1";
        $verifica = $this->conexao->query($sql)->fetch(PDO::FETCH_ASSOC);

        if($verifica != null){
             return true;
        
        }else{
            return false;

             
        }
        
    }

    public function tira_tarde_inst($cod_user,$cod_inst){

     $this->conexao->query("update maistarde_inst set ativo='0' WHERE cd_cod_tarinst = {$cod_inst} and  cd_cod_ido_tarinst ={$cod_user}");
        
    }
}