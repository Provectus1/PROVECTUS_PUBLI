<?php 

require __DIR__."/../conexao/Connection.php";

class Login{
    //ATRIBUTOS DA CLASSE
    public $email;
    public $senha;

    public $conexao;
 
    //COMPORTAMENTOS
    public function __construct(){
        $conexao_objeto = new Connection();
        $this->conexao = $conexao_objeto->getConnection();
    }

    public function verifica($email,$senha){
        $sql="select * from usuario where email = '{$email}' and senha = '{$senha}'";
        //echo $sql;
        $result_id = $this->conexao->query($sql)->fetch(PDO::FETCH_ASSOC);
        // echo "<pre>";
        // var_dump($result_id);
        // exit();
        //print_r($result_id);
        if($result_id != null){
            $_SESSION['logado'] = 'TRUE';
            $_SESSION['id_user'] = $result_id['id_user'];
            $_SESSION['tipo_user'] =$result_id['cd_cod_tipuser'];


            return true;
        }else{
            return false;
        }
    

    }


    public function deslogar(){

        $_SESSION['logado'] = 0;
        $_SESSION['id_user'] = 0;   
        //destroi a sessao
        session_destroy();
    }


}