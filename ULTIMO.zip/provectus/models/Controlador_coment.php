<?php 
    
require __DIR__."/../conexao/Connection.php";

class Coment{

	public $coment;
    public $conexao;
 
    public function __construct(){

        $conexao_objeto = new Connection();
        $this->conexao = $conexao_objeto->getConnection();
    }

    public function cad_com_inst ($id_inst, $id_ido, $coment){
    	$sql = "insert into coment_inst(cd_cod_cominst, cd_cod_ido_cominst, comentario) values ( $id_inst,$id_ido,'$coment')";
    	$this->conexao->exec($sql);
	}

    public function list_com_inst($cod_inst){
        $sql  = "select * from coment_inst where cd_cod_cominst = {$cod_inst};";
        $info = $this->conexao->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        //print_r($info);
        return $info;
    }
    
    public function edit_com_inst($cod_inst,$cod_ido,$coment){
        $sql = "update coment_inst set comentario='$coment' WHERE  cd_cod_cominst=$cod_inst and cd_cod_ido_cominst=$cod_ido";
        $this->conexao->exec($sql);

    }

    public function excluir_com_inst($cod_inst,$cod_ido){
        $sql = "delete from coment_inst where cd_cod_cominst=$cod_inst and cd_cod_ido_cominst=$cod_ido";
        $this->conexao->exec($sql);
    }
    
    public function edit_com_cuid($cod_cuid,$cod_ido,$coment){
        $sql = "update coment_cuid set comentario='$coment' WHERE  cd_id_ido_coment=$cod_ido and cd_id_cuid_coment=$cod_cuid";
        $this->conexao->exec($sql);

    }
    public function excluir_com_cuid($cod_cuid,$cod_ido){
        $sql = "delete from coment_cuid where cd_id_ido_coment=$cod_ido and cd_id_cuid_coment=$cod_cuid";
        $this->conexao->exec($sql);
    }
    public function cad_com_cuid ($id_ido,$id_cuid,$coment){
        $sql = "insert into coment_cuid(cd_id_ido_coment,cd_id_cuid_coment, comentario) values ( $id_ido,$id_cuid,'$coment')";
        $this->conexao->exec($sql);
    }

    public function cad_com_art ($cod_art,$id_user,$coment){
        $sql = "insert into coment_art(cd_id_user_comart, cd_cod_arti_comart, comentario) values ( $id_user,$cod_art,'$coment')";
        $this->conexao->exec($sql);
    }
    
    public function edit_com_art($cod_art,$id_user,$coment){
        $sql = "update coment_art set comentario='$coment' WHERE  cd_id_user_comart=$id_user and cd_cod_arti_comart=$cod_art";
        $this->conexao->exec($sql);

    }
    public function excluir_com_art($cod_art,$id_user){
        $sql = "delete from coment_art where cd_id_user_comart=$id_user and cd_cod_arti_comart=$cod_art";
        $this->conexao->exec($sql);
    }

}