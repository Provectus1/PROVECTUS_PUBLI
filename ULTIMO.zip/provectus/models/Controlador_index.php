<?php   
   
require_once __DIR__."/../conexao/Connection.php"; 

class Index{
 
    public $conexao;

    public function __construct(){ 

        $conexao_objeto = new Connection();
        $this->conexao = $conexao_objeto->getConnection();
    }

    public function listar_inst(){
       $result_lista_inst = $this->conexao->query("select cod_inst from Instituicoes")->fetchAll(PDO::FETCH_ASSOC);
       return $result_lista_inst;
    }


    public function getInstById_index($id_inst){
        $info = $this->conexao->query("select * from Instituicoes where cod_inst = {$id_inst}")->fetch(PDO::FETCH_ASSOC);
        return $info;
    }

    public function listar_cuid(){
       $result_lista_cuid = $this->conexao->query("select cd_id_user from cuidador")->fetchAll(PDO::FETCH_ASSOC);
       return $result_lista_cuid;
    }
   
    public function getCuidById_index($id_cuid){
       $total= array();

        $info_1 = $this->conexao->query("select nome,email,id_user from usuario where id_user = {$id_cuid}")->fetch(PDO::FETCH_ASSOC);
        $info_2 = $this->conexao->query("select estado,cidade from cuidador where cd_id_user = {$id_cuid}")->fetch(PDO::FETCH_ASSOC);
        $total[] = $info_1;
        $total[] = $info_2;
        return $total;
    }
    public function pegar_cuid_admin($id_user){
       $result_cod = $this->conexao->query("select id_cuid from cuidador where cd_id_user = {$id_user}")->fetchAll(PDO::FETCH_ASSOC);
       return $result_cod;
    }

    public function total_likes_inst_index($cod_inst){

     $result = $this->conexao->query("select count(cd_cod_ido_notinst) as qtd_like from nota_inst where cd_cod_notinst = {$cod_inst} and nota =1 ")->fetch(PDO::FETCH_ASSOC);
      return $result;
        
    }

}