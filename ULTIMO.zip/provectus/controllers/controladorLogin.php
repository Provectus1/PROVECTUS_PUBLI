<?php 
session_start(); 
/** 
 * Created by PhpStorm.
 * User: Bianca
 * Date: 13/08/2018
 * Time: 23:18
 */
require __DIR__."/../models/Usuario_login.php";

function index(){
    header('location: ../view/index.php');
}

function logar(){
    require __DIR__."/../view/login.php";
}

function fazLogin(){
      $email = $_POST['email'];
      $senha = $_POST['senha'];


    $login = new Login();
    $resultado = $login->verifica_login($email, $senha);

  /*  if ($resultado != 'false'){

        $user = new Login();
        $user->logado($email,$senha);

    }else {
        logar();
    }
*/

}

function sair(){
    $login = new Login();
    $resultado = $login->logout();
}


if (isset($_GET['acao'])) {
    $acao = $_GET['acao'];
}else {
    $acao = 'logar';
}

switch ($acao) {
        case 'fazLogin':
             $res = fazLogin($_POST['email'], $_POST['senha']);
            break;
        case 'sair':
            $res = sair();
            break;
    }

// if ($acao == 'logar'){
//     logar();
// } elseif ($_GET['acao'] == 'fazLogin'){
//     $res = fazLogin($_POST['email'], $_POST['senha']);
// }

// if ($acao == 'logar'){
//     logar();
// } elseif ($_GET['acao'] == 'sair'){
//     $res = sair();
// }

//
//if (isset($_GET['acao'])) {
//    $acao = $_GET['acao'];
//}else{
//    $acao = 'index';
//}
//
//if ($acao == 'fazLogin'){
//    $resultado = fazLogin($email, $senha);
//} elseif ($acao == 'logout'){
//    $resultado = sair();
//}

