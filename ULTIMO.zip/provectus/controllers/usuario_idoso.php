<?php   
session_start();      
    require __DIR__."/../models/Usuario_idoso.php";
 
    function index_idoso(){ 
        header('location: ../view/index.php');

    }

    function cadastrar_idoso(){
        require __DIR__."/../view/cadastro_idoso.php";
    }

    function salvar_idoso(){

        $nome_ido     = filter_input(INPUT_POST , 'nome', FILTER_SANITIZE_SPECIAL_CHARS);
        $email_ido    = $_POST['email_idoso'];
        $senha_ido    = $_POST['senha_idoso'];
        $cidade_ido   = $_POST['cidade_idoso'];
        $estado_ido   = $_POST['estado_idoso'];
        $tel_ido      = $_POST['tel_idoso'];


    if($nome_ido == null or $email_ido == null or $senha_ido == null){
        //erro 24 dados nulos
            header('location: ../view/cadastro_idoso.php?erro_cad=24');

    }else{

        $user_ido = new Usuario_idoso();
        $conf_ido = $user_ido->salvar_idoso($nome_ido, $email_ido, $senha_ido,$tel_ido,$cidade_ido,$estado_ido);
           
        if($conf_ido == true){
            //mensagem de erro na confirmacao do email
            // 22 codigo de erro = email repetido
          header('location: ../view/cadastro_idoso.php?erro_cad=22');

        }else{
            //logar automatico falta
           $cadastrado_ido=new Usuario_idoso();
           $result = $cadastrado_ido->loga_auto($email_ido,$senha_ido);

            if($result){
                //print_r($_FILES);
                index_idoso();
            }else{
                logar();
            }
        }
    }



    }


    function info_user_ido_pg($cod_user){

        $user_ido = new Usuario_idoso();
        $result_ido= $user_ido->getUserById($cod_user); 


        return $result_ido;

    }


    function atualizar_idoso(){

        $nome_ido     = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_SPECIAL_CHARS);
        $email_ido    = $_POST['email_idoso'];
        $senha_ido    = $_POST['senha_idoso'];
        $cidade_ido   = $_POST['cidade_idoso'];
        $estado_ido   = $_POST['estado_idoso'];
        $tel_ido      = $_POST['tel_idoso'];
        $id_user_ido  = $_SESSION['id_user'];


        $user_ido = new Usuario_idoso();
        $user_ido->update_idoso($id_user_ido, $nome_ido, $email_ido, $senha_ido,$tel_ido,$cidade_ido,$estado_ido);

        header('location: ../view/pagina_usuario.php');
    }

    function excluir_idoso(){

        $id_user_ido  = $_SESSION['id_user'];
        $id_ido_ido   = $_SESSION['id_ido'];

        $user_ido = new Usuario_idoso();
        $user_ido->delete_idoso($id_user_ido,$id_ido_ido);

        
        $_SESSION['logado'] = 0;
        $_SESSION['id_user'] = 0;   
        //destroi a sessao
        session_destroy();
        header('location: ../view/index.php');    
     }

    function info_cuid_anuncio($cod_cuid){

      $cuid = new Usuario_idoso();
      $result_info= $cuid->getCuidById_anuncio($cod_cuid); 
      return $result_info;

    }

    function cuid_coment($cod_cuid){
        $coment_cuid = new Usuario_idoso();
        $result_coment= $coment_cuid->coment_cuid_lista($cod_cuid);
        return $result_coment; 

    }

    function lista_nome_ido_cuid($cod_ido){

        $user_ido = new Usuario_idoso();
        $result_ido= $user_ido->getUserById_idoso($cod_ido); 
        return $result_ido;

    }

    function like_cuid(){
        $cod_ido = $_GET['cod_ido'];
        $cod_cuid = $_GET['cod_cuid'];
        $cod_user = $_GET['cod_user'];

        $curtir = new Usuario_idoso();
        $curtir->curtir_cuid($cod_ido,$cod_cuid);

     header('location: ../view/anuncio_cuid.php?id_cuid='.$cod_user);


    }
    
    function verifica_like_cuid($cod_ido,$cod_cuid){


       $verifica = new Usuario_idoso();
       $result = $verifica->existe_like_cuid($cod_ido,$cod_cuid);

       return $result;

    }
    
    function dislike_cuid(){
        $cod_ido = $_GET['cod_ido'];
        $cod_cuid = $_GET['cod_cuid'];
        $cod_user = $_GET['cod_user'];

        $curtir = new Usuario_idoso();
        $curtir->descurtir_cuid($cod_ido,$cod_cuid);

     header('location: ../view/anuncio_cuid.php?id_cuid='.$cod_user);

    }

    function count_like_cuid($cod_cuid){


       $verifica = new Usuario_idoso();
       $result = $verifica->total_likes_cuid($cod_cuid);

       return $result;

    }

    function cod_inst_maistarde($cod_ido){
       $verifica = new Usuario_idoso();
       $result = $verifica->lista_maistarde_inst($cod_ido);

       return $result;

    }

    function info_inst_maistarde($cod_inst){
        $verifica = new Usuario_idoso();
        $result = $verifica->informacao_inst_maistarde($cod_inst);

       return $result;

    }

    function cod_art_maistarde($cod_user){
       $verifica = new Usuario_idoso();
       $result = $verifica->lista_maistarde_art($cod_user);

       return $result;

    }

    function info_art_maistarde($cod_art){
        $verifica = new Usuario_idoso();
        $result = $verifica->informacao_art_maistarde($cod_art);

       return $result;

    }
    function verifica_tarde_cuid($cod_ido,$cod_cuid){


       $verifica = new Usuario_idoso();
       $result = $verifica->existe_tarde_cuid($cod_ido,$cod_cuid);

       return $result;

    }

    function tiratarde_cuid(){
        $cod_ido = $_GET['cod_ido'];
        $cod_cuid = $_GET['cod_cuid'];
        $cod_user = $_GET['cod_user'];

        $curtir = new Usuario_idoso();
        $curtir->tira_tarde_cuid($cod_ido,$cod_cuid);

    header('location: ../view/anuncio_cuid.php?id_cuid='.$cod_user);


    }

    function maistarde_cuid(){
        $cod_ido = $_GET['cod_ido'];
        $cod_cuid = $_GET['cod_cuid'];
        $cod_user = $_GET['cod_user'];


        $curtir = new Usuario_idoso();
        $curtir->tarde_cuid($cod_ido,$cod_cuid);

    header('location: ../view/anuncio_cuid.php?id_cuid='.$cod_user);


    }

    function cod_cuid_maistarde($cod_ido){
       $verifica = new Usuario_idoso();
       $result = $verifica->lista_maistarde_cuid($cod_ido);

       return $result;

    }
   
    function info_cuid_maistarde($cod_cuid){
        $verifica = new Usuario_idoso();
        $result = $verifica->informacao_cuid_maistarde($cod_cuid);

       return $result;

    } 




    if (isset($_GET['acao']) and function_exists($_GET['acao']) ){
        call_user_func($_GET['acao']);
    }else {
       
    }


