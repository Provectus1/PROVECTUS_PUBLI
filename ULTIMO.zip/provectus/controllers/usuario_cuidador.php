<?php 
session_start();  
 
    require __DIR__."/../models/Usuario_cuidador.php";

    function index(){
        header('location: ../view/index.php');

    }

    function cadastrar_cuid(){
        require __DIR__."/../view/cadastro_cuid.php";
    }

    function salvar(){

        $nome     = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_SPECIAL_CHARS);
        $email    = $_POST['email_cuid'];
        $senha    = $_POST['senha_cuid'];
        $tel      = $_POST['tel_cuid'];
        $cidade   = $_POST['cidade_cuid'];
        $estado   = $_POST['estado_cuid'];
        $texto    = $_POST['info_cuid'];
        $valor    = $_POST['pagamento_cuid']; 

        if($nome == null or $email == null or $senha == null){
        //erro 24 dados nulos
            header('location: ../view/cadastro_cuid.php?erro_cad=24');

        }else{

        // print_r($_POST['senha_idoso']);

        $user = new Usuario_cuid();

        $conf = $user->salvar_cuid($nome, $email, $senha,$tel,$cidade,$estado,$texto,$valor);

         
        if($conf == true){
            //mensagem de erro na confirmacao do email
         //header('location: ../view/cadastro_idoso.php?erro_cad=22');

        }else{
            //logar automatico falta
           $cadastrado_cuid=new Usuario_cuid();
           $result = $cadastrado_cuid->loga_auto($email,$senha);

            if($result){
                index();
            }else{
                logar();
            }
        }
    }
        
    }

    function info_user($cod_user){

        $user = new Usuario_cuid();
        $result= $user->getUserById($cod_user); 


        return $result;
    }

    function atualizar(){
        $nome     = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_SPECIAL_CHARS);
        $email    = $_POST['email'];
        $senha    = $_POST['senha'];
        $tel      = $_POST['tel'];
        $cidade   = $_POST['cidade'];
        $estado   = $_POST['estado'];
        $texto    = $_POST['texto'];
        $valor    = $_POST['valor'];
        $id_user  = $_SESSION['id_user'];


        $user = new Usuario_cuid();
        $user->update_cuidador($id_user, $nome, $email, $senha,$tel,$cidade,$estado,$texto,$valor);

        header('location: ../view/pagina_usuario.php');

    }

    function excluir(){ 
  
        $id_user  = $_SESSION['id_user'];
        $id_cuid  = $_SESSION['id_cuid'];

        $user = new Usuario_cuid();
        $user->delete_cuidador($id_user,$id_cuid);

  
        $_SESSION['logado'] = 0;
        $_SESSION['id_user'] = 0;   
        //destroi a sessao
        session_destroy();
        index();
    }

    function excluir_admin(){ 

        $id_cuid  = $_GET['id_cuid'];
        $id_user  = $_GET['id_user'];

      $user = new Usuario_cuid();
      $user->delete_cuidador($id_user,$id_cuid);


       header('location: ../view/gerenciamento_cuid.php');

        

    }





    if (isset($_GET['acao']) and function_exists($_GET['acao']) ){
        call_user_func($_GET['acao']);
    }else {
    }

