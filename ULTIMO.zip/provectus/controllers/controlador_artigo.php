 <?php  
session_start();    
   
require __DIR__."/../models/Controlador_artigo.php";



    function info_artigo($cod_artigo){

       $arti = new Artigo();
       $result= $arti->getArtigotById($cod_artigo); 
       return $result;

    }

    function lista_arti($cod_categoria){

        $lista_art = new Artigo();
        $result_lista= $lista_art->listar_arti($cod_categoria); 
        return $result_lista;

    }

   function salvar_artigo(){

        $titulo_artigo     = filter_input(INPUT_POST , 'titulo', FILTER_SANITIZE_SPECIAL_CHARS);
        $autor_artigo   = $_POST['autor'];
        $texto_artigo   = $_POST['texto'];
        $data_artigo   = $_POST['data'];
        $cod_cat   = $_GET['cod_cat'];
        $img_artigo      = 'null';

        // print_r($_POST['senha_idoso']);
        if($titulo_artigo == null or $autor_artigo == null){
        //erro 24 dados nulos
            header('location: ../view/cadastro_art.php?erro_cad=24');

        }else{

        $art = new Artigo();
        $conf = $art->salvar_artigo($texto_artigo,$titulo_artigo,$autor_artigo,$data_artigo,1,$cod_cat);
    
        if($conf == true){
            //mensagem de erro "já existe uma Instituicao com esse nome neste baairro"
            // erro 27 inst já cadastrada
           header('location: ../view/cadastro_art.php?erro_cad=27');

        }else{
           $traz_id= new Artigo();
           $id_art= $traz_id->getId_art($titulo_artigo);

            
           header('location: ../view/artigo.php?id_arti='.$id_art['cod_arti']);
        }
    }
    }

    function atualizar_artigo(){

        $titulo_artigo     = filter_input(INPUT_POST , 'titulo', FILTER_SANITIZE_SPECIAL_CHARS);
        $autor_artigo   = $_POST['autor'];
        $texto_artigo   = $_POST['texto'];
        $data_artigo   = $_POST['data'];
        $cod_cat   = $_GET['cod_cat'];
        $img_artigo      = 'null';

        $id_art       = $_GET['id_arti'];



        $art = new Artigo();
        $art->update_art($texto_artigo,$titulo_artigo,$autor_artigo,$data_artigo, $id_art);

        header('location: ../view/artigo.php?id_arti='.$id_art);
    }
    
    function excluir_artigo(){
        $id_art = $_GET['id_arti'];

        $exc_art = new Artigo();
        $exc_art->deleta_art($id_art); 

        if($_GET['gerenci'] == 1){
            header('location: ../view/gerenciamento_art.php');
        }else{
            header('location: ../view/index.php');
        }

        
    }
    function art_coment($cod_art){
        $coment_art = new Artigo();
        $result_coment= $coment_art->coment_art_lista($cod_art);
        return $result_coment; 

    }

    function lista_nome_ido_art($cod_ido){

        $user_ido = new Artigo();
        $result_ido= $user_ido->getUserById_idoso_art($cod_ido); 
        return $result_ido;

    }


    function like_art(){
        $cod_user = $_GET['cod_user'];
        $cod_art = $_GET['cod_art'];


        $curtir = new Artigo();
        $curtir->curtir_art($cod_user,$cod_art);

     header('location: ../view/artigo.php?id_arti='.$cod_art);

    }
    
    function verifica_like_art($cod_user,$cod_art){


       $verifica = new Artigo();
       $result = $verifica->existe_like_art($cod_user,$cod_art);

       return $result;

    }
    
    function dislike_art(){
        $cod_user = $_GET['cod_user'];
        $cod_art = $_GET['cod_art'];

        $curtir = new Artigo();
        $curtir->descurtir_art($cod_user,$cod_art);

     header('location: ../view/artigo.php?id_arti='.$cod_art);

    }

    function count_like_art($cod_art){


       $verifica = new Artigo();
       $result = $verifica->total_likes_art($cod_art);

       return $result;

    }


    function verifica_tarde_art($cod_user,$cod_art){
       $verifica = new Artigo();
       $result = $verifica->existe_tarde_art($cod_user,$cod_art);

       return $result;
    }
   

    function maistarde_art(){
        $cod_user = $_GET['cod_user'];
        $cod_art = $_GET['cod_art'];

        $curtir = new Artigo();
        $curtir->tarde_art($cod_user,$cod_art);

    header('location: ../view/artigo.php?id_arti='.$cod_art);


    }
    function tiratarde_art(){
        $cod_user = $_GET['cod_user'];
        $cod_art = $_GET['cod_art'];
        $curtir = new Artigo();
        $curtir->tira_tarde_art($cod_user,$cod_art);


    header('location: ../view/artigo.php?id_arti='.$cod_art);


    }

    



if (isset($_GET['acao']) and function_exists($_GET['acao']) ){
    call_user_func($_GET['acao']);
}else{
       
}
