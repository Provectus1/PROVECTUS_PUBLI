 <?php 
session_start();        
 
require __DIR__."/../models/Controlador_inst.php";

   // function inst(){
     //   header('location: ../view/anuncio_inst.php?id_inst=1');

    //}

    function info_inst($cod_inst){
        $inst = new Inst();
        $result= $inst->getInstById($cod_inst); 
        return $result;

    }

    function inst_coment($cod_inst){
        $coment = new Inst();
        $result_coment= $coment->coment_inst_lista($cod_inst);
        return $result_coment; 

    }


    function lista_nome_ido($cod_ido){

        $user_ido = new Inst();
        $result_ido= $user_ido->getUserById_idoso($cod_ido); 
        return $result_ido;

    }

    function salvar_inst(){

        $nome_inst     = filter_input(INPUT_POST , 'nome', FILTER_SANITIZE_SPECIAL_CHARS);
        $email_inst    = $_POST['email_inst'];
        $cidade_inst   = $_POST['cidade_inst'];
        $estado_inst   = $_POST['estado_inst'];
        $rua_inst      = $_POST['rua_inst'];
        $bairro_inst   = $_POST['bairro_inst'];
        $num_inst      = $_POST['num_inst'];
        $tel_inst      = $_POST['cel_inst'];
        $texto_inst    = $_POST['texto_inst'];
 

        // print_r($_POST['senha_idoso']);
        if($nome_inst == null or $tel_inst == null){
        //erro 24 dados nulos
            header('location: ../view/cadastro_inst.php?erro_cad=24');

        }else{

        $inst = new Inst();
        $conf = $inst->salvar_inst_model($tel_inst,$texto_inst,$cidade_inst,$nome_inst,$rua_inst,$email_inst,$estado_inst,$num_inst,$bairro_inst);
    
        if($conf == true){
            //mensagem de erro "já existe uma Instituicao com esse nome neste baairro"
            // erro 27 inst já cadastrada
           header('location: ../view/cadastro_inst.php?erro_cad=27');

        }else{
           $traz_id= new Inst();
           $id_inst= $traz_id->getId_inst($nome_inst,$bairro_inst);
            
           header('location: ../view/anuncio_inst.php?id_inst='.$id_inst['cod_inst']);
        }
    }
    }

    function atualizar_inst(){

        $nome_inst     = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_SPECIAL_CHARS);
        $email_inst    = $_POST['email_inst'];
        $cidade_inst   = $_POST['cidade_inst'];
        $estado_inst   = $_POST['estado_inst'];
        $tel_inst      = $_POST['tel_inst'];
        $num_inst      = $_POST['num_inst'];
        $rua_inst      = $_POST['rua_inst'];
        $bairro_inst   = $_POST['bairro_inst'];
        $texto_inst    = $_POST['texto_inst'];

        $id_inst       = $_GET['id_inst'];



        $inst = new Inst();
        $inst->update_inst($tel_inst,$texto_inst,$cidade_inst,$nome_inst,$rua_inst,$email_inst,$estado_inst,$num_inst,$id_inst,$bairro_inst);

        header('location: ../view/anuncio_inst.php?id_inst='.$id_inst);
    }

    function excluir_inst(){
        $id_inst = $_GET['id_inst'];
        $tipo_user = $_SESSION['tipo_user'];

        $exc_inst = new Inst();
        $exc_inst->deleta_inst($id_inst); 

        if($tipo_user == 1 and $_GET['gerenci'] == 1 ){

             header('location: ../view/gerenciamento_inst.php');

        }else{

            header('location: ../view/index.php');

        }

        
    }
   
    function like_inst(){
        $cod_user = $_GET['cod_user'];
        $cod_inst = $_GET['cod_inst'];

        $curtir = new Inst();
        $curtir->curtir_inst($cod_user,$cod_inst);

    header('location: ../view/anuncio_inst.php?id_inst='.$cod_inst);


    }
    
    function verifica_like_inst($cod_user,$cod_inst){


       $verifica = new Inst();
       $result = $verifica->existe_like($cod_user,$cod_inst);

       return $result;

    }
    
    function dislike_inst(){
        $cod_user = $_GET['cod_user'];
        $cod_inst = $_GET['cod_inst'];

        $curtir = new Inst();
        $curtir->descurtir_inst($cod_user,$cod_inst);

        header('location: ../view/anuncio_inst.php?id_inst='.$cod_inst);


    }

    function count_like_inst($cod_inst){


       $verifica = new Inst();
       $result = $verifica->total_likes_inst($cod_inst);

       return $result;

    }

    function maistarde_inst(){
        $cod_user = $_GET['cod_user'];
        $cod_inst = $_GET['cod_inst'];

        $curtir = new Inst();
        $curtir->tarde_inst($cod_user,$cod_inst);

    header('location: ../view/anuncio_inst.php?id_inst='.$cod_inst);


    }
  
    function verifica_tarde_inst($cod_user,$cod_inst){


       $verifica = new Inst();
       $result = $verifica->existe_tarde_inst($cod_user,$cod_inst);

       return $result;

    }
    function tiratarde_inst(){
        $cod_user = $_GET['cod_user'];
        $cod_inst = $_GET['cod_inst'];

        $curtir = new Inst();
        $curtir->tira_tarde_inst($cod_user,$cod_inst);

    header('location: ../view/anuncio_inst.php?id_inst='.$cod_inst);


    }


if (isset($_GET['acao']) and function_exists($_GET['acao']) ){
    call_user_func($_GET['acao']);
}else{

}