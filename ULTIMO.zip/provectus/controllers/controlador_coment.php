 <?php 
session_start();     
 
require __DIR__."/../models/Controlador_coment.php";

    function coment_inst(){ 
    	$coment = $_POST['coment_realiza'];
    	$id_inst = $_GET['cod_inst'];
      $id_ido = $_SESSION['id_ido'];

      echo $coment;
      echo $id_ido;

     $comentario = new Coment();
     $comentario->cad_com_inst($id_inst, $id_ido, $coment);

      header('location: ../view/anuncio_inst.php?id_inst='.$id_inst);
    }

    function listar_inst_coment($cod_inst){

      $listar = new Coment();
      $lista_coment= $listar->list_com_inst($cod_inst);
      return $lista_coment;
        
    }

    function atualizar_coment_inst(){
      $cod_inst = $_GET['cod_inst'];
      $cod_ido  = $_GET['id_ido'];
      $coment   = $_POST['coment'];
      $edit_coment= new Coment();
      $edit_coment->edit_com_inst($cod_inst,$cod_ido,$coment);
       header('location: ../view/anuncio_inst.php?id_inst='.$cod_inst);

        
    }

    function excluir_coment_inst(){
      $cod_inst = $_GET['cod_inst'];
      $cod_ido  = $_GET['id_ido'];
      $excluir_coment= new Coment();
      $excluir_coment->excluir_com_inst($cod_inst,$cod_ido);
       header('location: ../view/anuncio_inst.php?id_inst='.$cod_inst);

    }

    function atualizar_coment_cuid(){
      $cod_cuid     = $_GET['id_cuid'];
      $cod_cuid_cod = $_GET['id_cuid_id'];
      $cod_ido      = $_GET['id_ido'];
      $coment       = $_POST['coment'];
      $edit_coment  = new Coment();
      $edit_coment->edit_com_cuid($cod_cuid_cod,$cod_ido,$coment);
       header('location: ../view/anuncio_cuid.php?id_cuid='.$cod_cuid);

        
    }

    function excluir_coment_cuid(){
      $cod_cuid      = $_GET['id_cuid'];
      $cod_cuid_cod  = $_GET['id_cuid_id'];
      $cod_ido       = $_GET['id_ido'];
      $excluir_coment= new Coment();
      $excluir_coment->excluir_com_cuid($cod_cuid_cod,$cod_ido);
       header('location: ../view/anuncio_cuid.php?id_cuid='.$cod_cuid);

    }
   
    function coment_cuid(){ 
      $coment       = $_POST['coment_realiza'];
      $cod_cuid     = $_GET['id_cuid'];
      $cod_cuid_cod = $_GET['id_cuid_id'];
      $cod_ido      = $_GET['id_ido'];

    $comentario = new Coment();
    $comentario->cad_com_cuid($cod_ido,$cod_cuid_cod,$coment);

    header('location: ../view/anuncio_cuid.php?id_cuid='.$cod_cuid);
    }
 

    function coment_art(){ 
      $coment       = $_POST['coment_realiza'];
      $cod_art    = $_GET['id_arti'];
      $id_user = $_GET['id_user'];
    

    $comentario = new Coment();
    $comentario->cad_com_art($cod_art,$id_user,$coment);

    header('location: ../view/artigo.php?id_arti='.$cod_art);
    }

    function atualizar_coment_art(){
      $cod_art      = $_GET['id_arti'];
      $id_user      = $_GET['id_user'];
      $coment       = $_POST['coment'];
     
      $edit_coment  = new Coment();
      $edit_coment->edit_com_art($cod_art,$id_user,$coment);
      
      header('location: ../view/artigo.php?id_arti='.$cod_art);

        
    }

    function excluir_coment_art(){
      $cod_art      = $_GET['id_arti'];
      $id_user      = $_GET['id_user'];
     
      $excluir_coment= new Coment();
      $excluir_coment->excluir_com_art($cod_art,$id_user);
      
      header('location: ../view/artigo.php?id_arti='.$cod_art);

    }


if (isset($_GET['acao']) and function_exists($_GET['acao']) ){
   call_user_func($_GET['acao']);
}else{
}