 <?php 
session_start();    
 
require_once __DIR__."/../models/Controlador_index.php";

    function lista_inst(){

        $lista_inst = new Index();
        $result_lista= $lista_inst->listar_inst(); 
        return $result_lista;

    }

    function info_inst_index($cod_inst){

       $inst = new Index();
       $result= $inst->getInstById_index($cod_inst); 
       return $result;

    }

    function lista_cuid(){

        $lista_cuid = new Index();
        $result_lista= $lista_cuid->listar_cuid(); 
        return $result_lista;

    }


    function info_cuid_index($cod_cuid){
 
       $cuid = new Index();
       $result= $cuid->getCuidById_index($cod_cuid); 
       return $result;

    }
    

    function pega_cod($cod_user){
 
       $cuid = new Index();
       $result= $cuid->pegar_cuid_admin($cod_user); 
       return $result;

    } 

    function count_like_inst_index($cod_inst){


       $verifica = new Index();
       $result = $verifica->total_likes_inst_index($cod_inst);

       return $result;

    }
