<?php  
 session_start();  
require __DIR__."/../models/Usuario_login.php";

function index(){
  header('location: ../view/index.php');

}


function logar(){
	header('location: ../view/login.php');
}

function fazlogin(){
  $email = $_POST['email'];
  $senha = $_POST['senha'];
     
    $user=new Login();
    $result= $user->verifica($email, $senha);
    // print_r($result);
    if($result){
      index();
    }else{
      //erro 25: dados invalidos
       header('location: ../view/login.php?erro_cad=25');
    }

}

function sair(){
  $user=new Login();
  $user->deslogar();
  index();

}


if (isset($_GET['acao']) and function_exists($_GET['acao']) ){
  call_user_func($_GET['acao']);
}else{
  //index();
}

?>