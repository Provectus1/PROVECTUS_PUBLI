/*INSERT INTO categoria (tipo) VALUES
('lazer'),
('fisica'),
('psicologica');

INSERT INTO filtro (tipo) VALUES
('idoso'),
('cuidador');

INSERT INTO tipo_user (tipo) VALUES
('admin'),
('idoso'),
('cuidador');
*/
/*INSERT 	INTO usuario(nome,tel,email,senha,cd_cod_tipuser) VALUES
('Teresinha Simone Marcela Peixoto','(67)35221-3231','teresinha.marceka@gmail.com', '123TETE', 2),
('Levi Geraldo Peixoto','(67)58747-7232','levi.geraldo@gmail.com', '123levi', 2),
('Rosa Eduarda','(67)55416-6323','rosa.eduarda@gmail.com', '123rosa', 2),
('Vitor Anthony de Paula','(47)22152-5364','vitor.paula@gmail.com', '123vitor', 3),
('Marlene Brenda Aparecida','(47)25129-4764','marlene.aparecida@gmail.com', '123marlene', 2),
('Luís Pietro de Paula','(47)25674-5762','luis.pietro@gmail.com', '123luis', 3),
('Laryssa Jungton Sarti','(47)99735-1812','laryssa.jungton@gmail.com', 'admin', 1),
('Tuane Ronchi','(47)99252-8509','tuaneronchiwork@gmail.com', 'admin', 1),
('Clara SOuza de Jesus','(47)98461-4566','clarasouzadejesus16@gmail.com', 'admin', 1),
('Sebastiana Débora Aurora Ramos','(11)95851-4176','sebastiana.aurora@gmail.com', '123sebastiana', 2),
('Tereza Regina da Mota','(11)95321-0886','tereza.mota@gmail.com', '123tereza', 3),
('Sebastião Cardoso','(11)55301-0886','sebastiao.cardoso@gmail.com', '123sebas', 3),
('Sebastião Cardoso','(11)55301-0886','sebastiao.cardoso@gmail.com', '123sebas', 3),
('Aline Frota','(11)45601-0886','aline.frota@gmail.com', '123alin', 3);
*/
INSERT 	INTO idoso(estado,cidade,cd_id_user) VALUES
('SC','Joinville', 15),
('PR','São José dos Pinhais', 16),
('SP', 'São Paulo', 17),
('SC', 'Floripa', 19),
('SP', 'São Paulo', 24);


INSERT INTO cuidador(estado,cidade,texto,valor,curric, cd_id_user) VALUES
('SC','Joinville',' CUIDADOR 1 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed ullamcorper ipsum. 
Pellentesque vitae neque aliquet lorem hendrerit sollicitudin. Cras consequat vestibulum velit eget faucibus. Fusce aliquet eros vulputate neque interdum pulvinar. 
Curabitur ut lacinia sem. Integer tincidunt odio nisi, nec commodo neque vehicula nec. 
Nullam porttitor ante erat, et venenatis lorem gravida id.
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed ullamcorper ipsum. 
Pellentesque vitae neque aliquet lorem hendrerit sollicitudin.
 Cras consequat vestibulum velit eget faucibus. Fusce aliquet eros vulputate neque interdum pulvinar','R$1100.00','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed ullamcorper ipsum. 
Pellentesque vitae neque aliquet lorem hendrerit sollicitudin. Cras consequat vestibulum velit eget faucibus. Fusce aliquet eros vulputate neque interdum pulvinar. 
Curabitur ut lacinia sem. Integer tincidunt odio nisi, nec commodo neque vehicula nec. 
Nullam porttitor ante erat, et venenatis lorem gravida id.
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed ullamcorper ipsum.',18),

('RJ','Rio de Janeiro',' CUIDADOR 2 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed ullamcorper ipsum. 
Pellentesque vitae neque aliquet lorem hendrerit sollicitudin. Cras consequat vestibulum velit eget faucibus. Fusce aliquet eros vulputate neque interdum pulvinar. 
Curabitur ut lacinia sem. Integer tincidunt odio nisi, nec commodo neque vehicula nec. 
Nullam porttitor ante erat, et venenatis lorem gravida id.
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed ullamcorper ipsum. 
Pellentesque vitae neque aliquet lorem hendrerit sollicitudin.
 Cras consequat vestibulum velit eget faucibus. Fusce aliquet eros vulputate neque interdum pulvinar','R$1200.00','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed ullamcorper ipsum. 
Pellentesque vitae neque aliquet lorem hendrerit sollicitudin. Cras consequat vestibulum velit eget faucibus. Fusce aliquet eros vulputate neque interdum pulvinar. 
Curabitur ut lacinia sem. Integer tincidunt odio nisi, nec commodo neque vehicula nec. 
Nullam porttitor ante erat, et venenatis lorem gravida id.
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed ullamcorper ipsum.',20),

('SP','São Paulo',' CUIDADOR 3 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed ullamcorper ipsum. 
Pellentesque vitae neque aliquet lorem hendrerit sollicitudin. Cras consequat vestibulum velit eget faucibus. Fusce aliquet eros vulputate neque interdum pulvinar. 
Curabitur ut lacinia sem. Integer tincidunt odio nisi, nec commodo neque vehicula nec. 
Nullam porttitor ante erat, et venenatis lorem gravida id.
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed ullamcorper ipsum. 
Pellentesque vitae neque aliquet lorem hendrerit sollicitudin.
 Cras consequat vestibulum velit eget faucibus. Fusce aliquet eros vulputate neque interdum pulvinar','R$1300.00','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed ullamcorper ipsum. 
Pellentesque vitae neque aliquet lorem hendrerit sollicitudin. Cras consequat vestibulum velit eget faucibus. Fusce aliquet eros vulputate neque interdum pulvinar. 
Curabitur ut lacinia sem. Integer tincidunt odio nisi, nec commodo neque vehicula nec. 
Nullam porttitor ante erat, et venenatis lorem gravida id.
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed ullamcorper ipsum.',25),

('SC','Florianópolis','CUIDADOR 4 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed ullamcorper ipsum. 
Pellentesque vitae neque aliquet lorem hendrerit sollicitudin. Cras consequat vestibulum velit eget faucibus. Fusce aliquet eros vulputate neque interdum pulvinar. 
Curabitur ut lacinia sem. Integer tincidunt odio nisi, nec commodo neque vehicula nec. 
Nullam porttitor ante erat, et venenatis lorem gravida id.
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed ullamcorper ipsum. 
Pellentesque vitae neque aliquet lorem hendrerit sollicitudin.
 Cras consequat vestibulum velit eget faucibus. Fusce aliquet eros vulputate neque interdum pulvinar','R$1400.00','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed ullamcorper ipsum. 
Pellentesque vitae neque aliquet lorem hendrerit sollicitudin. Cras consequat vestibulum velit eget faucibus. Fusce aliquet eros vulputate neque interdum pulvinar. 
Curabitur ut lacinia sem. Integer tincidunt odio nisi, nec commodo neque vehicula nec. 
Nullam porttitor ante erat, et venenatis lorem gravida id.
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed ullamcorper ipsum.',26),

('DF','Brasília',' CUIDADOR 5 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed ullamcorper ipsum. 
Pellentesque vitae neque aliquet lorem hendrerit sollicitudin. Cras consequat vestibulum velit eget faucibus. Fusce aliquet eros vulputate neque interdum pulvinar. 
Curabitur ut lacinia sem. Integer tincidunt odio nisi, nec commodo neque vehicula nec. 
Nullam porttitor ante erat, et venenatis lorem gravida id.
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed ullamcorper ipsum. 
Pellentesque vitae neque aliquet lorem hendrerit sollicitudin.
 Cras consequat vestibulum velit eget faucibus. Fusce aliquet eros vulputate neque interdum pulvinar','R$1500.00','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed ullamcorper ipsum. 
Pellentesque vitae neque aliquet lorem hendrerit sollicitudin. Cras consequat vestibulum velit eget faucibus. Fusce aliquet eros vulputate neque interdum pulvinar. 
Curabitur ut lacinia sem. Integer tincidunt odio nisi, nec commodo neque vehicula nec. 
Nullam porttitor ante erat, et venenatis lorem gravida id.
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed ullamcorper ipsum.',27);
/*
INSERT INTO coment_cuid(comentario,hora,dat) VALUES
('Você é o melhor profissional que eu já tive contato nesse site',19:14,02/10/2019)
('Nossa, péssimo cuidado',09:31,20/12/2017)
('Poderia melhorar na questão da pontualidade',20:41,02/07/2018)
('Extremamente pontual e muito profissional, gostei',22:03,17/11/2015)
('Adorei o seu cuidado',05:30,10/02/2020);

INSERT INTO nota_cuid(nota) VALUES
(4)
(5)
(1)
(3)
(5);

INSERT INTO maistarde_cuid VALUES
(4)
(5)
(1)
(3)
(5);
*/

/*
INSERT INTO  artigo(conteudo,titulo,hora,autor,dat,cd_cod_filtro,cd_cod_cat) VALUES
('José Roberto Ribeiro, de 65 anos, é contador e já passou por diversos trabalhos. Atuou no ramo e foi dono de bar. Após desistir de manter um comércio, assumiu postos no serviço público por vários anos. Mas, recentemente, as oportunidades rarearam. Fez um curso de cuidador de idosos, conseguiu alguns serviços, mas sofria com a irregularidade do trabalho. “Hora você tem, hora você não tem”, conta.
 
De dono de bar, foi trabalhar em outro estabelecimento, agora como funcionário. Dois anos atrás, conseguiu um novo emprego em um ministério. Mas a vaga ocupada pelo contador era de auxiliar administrativo. “Estou bem, mas ganhando pouco. Tenho filho para criar, gastos com moradia”, afirmou à Agência Brasil.
 
A situação de José Roberto ilustra uma tendência crescente entre brasileiros acima dos 65 anos. Segundo dados da Secretaria de Trabalho do Ministério da Economia disponíveis na Relação Anual de Informações Sociais (RAIS), o número de pessoas com 65 anos ou mais em vagas com carteira assinada aumentou, saindo de 484 mil em 2013 para 649,4 mil em 2017. Foi uma ampliação de 43% em quatro anos.
 
De acordo com a coordenadora do observatório do trabalho da Secretaria de Trabalho, Mariana Almeida, com a procura maior por emprego de pessoas nessa faixa etária há um aumento do desemprego nesse segmento.

Conforme dados da Pesquisa Nacional por Amostra de Domicílios (PNAD) Contínua, o desemprego entre os idosos saiu de 18,5% em 2013 para 40,3 em 2018.

“Estamos tendo mais pessoas nesta faixa etária. A oferta é maior e aumenta o desemprego”, explica a coordenadora.
Na avaliação do coordenador de trabalho e rendimento do Instituto Brasileiro de Geografia e Estatística (IBGE), Cimar Azeredo, há uma série de fatores que contribuem para essa tendência. Um deles é o envelhecimento da população. Segundo o IBGE, em 2010 o percentual de pessoas idosas era de 7,32%. Nas projeções do instituto, este índice deve chegar este ano a 9,52% e, em 2060, a 25,5%.
 
A razão central para o crescimento da presença maior de idosos trabalhando, acrescenta o coordenador, é a falta de renda e a busca por meios para custear as despesas não somente da pessoa, mas da família. Esse esforço é particularmente maior em um cenário de crise econômica, como o que vem marcando o Brasil nos últimos anos. Este contexto torna ainda mais difícil a inserção das pessoas desta faixa etária.
 
“A crise provoca instabilidade no rendimento de trabalho, principalmente, o que acaba fazendo que população mais.','Total de idosos no mercado de trabalho cresce; precariedade aumenta','11:14:00', 'Jonas Valente','2019-05-01',1,1),

('Visita após visita, Pei Chen esperava conseguir convencer uma paciente com diabetes tipo 2 a autorizar o aumento dos níveis de açúcar no sangue. Sim, aumentar. A mulher, que tinha 84 anos quando foi pela primeira vez à clínica geriátrica da Universidade da Califórnia, em São Francisco, convivia com a doença havia décadas e seguia um tratamento complexo envolvendo autocontrole glicêmico frequente e injeções diárias de dois tipos de insulina. Médicos geriátricos costumam encorajar pacientes idosos com saúde mais debilitada a não exagerar nos esforços em busca de uma glicemia muito baixa (uma abordagem conhecida como "desintensificação"), com a justificativa de que o equilíbrio entre benefícios e riscos muda com a idade e a doença."Ela se sentia tonta e nauseada, suava muito", descreveu Chen. Foi apenas nesse momento que a paciente, já com 87 anos, aceitou deixar de lado a insistência em manter um controle tão severo1','Uma nova estratégia para o tratamento da diabetes em idosos: relaxar','11:27:00','Paula Span','2019/05/02',2,3),

('Apesar de comum, a vacina contra a gripe ainda causa dúvidas em muita gente. Para que a imunização não deixe questões, respondemos as principais perguntas sobre segurança e efetividade com as diretrizes da SBIm (Sociedade Brasileira de Imunizações) e a ajuda da médica Isabella Ballalai, vice-presidente da SBIm. Confira. 1) Quem deve tomar a vacina contra a gripe? A SBIm recomenda que todas as pessoas a partir dos seis meses de idade sejam vacinadas. No entanto, apenas o grupo com maior risco foi considerado prioritário pelo Ministério da Saúde em 2019 e pode vacinar-se gratuitamente. Fazem parte dele:Crianças de seis meses a menores de seis anos; Gestantes; Puérperas (mulheres até 45 dias após o parto); Trabalhadores da saúde, professores, povos indígenas, idosos, portadores de doenças crônicas, adolescentes e jovens de 12 a 21 anos de idade sob medidas socioeducativas, bem como a população privada de liberdade e os funcionários do sistema prisional.2) A vacina oferece algum risco para idosos? Não. "A vacina é inativada, não tem vírus vivo. É composta de proteínas que não são capazes de causar doenças. Pacientes com câncer, imunosuprimidos... Todos podem e devem ser vacinados", explica Ballalai. Além disso, de acordo com um estudo publicado no periódico Canadian Medical Association Journal, idosos que se vacinam contra a gripe todos os anos têm menos chances de serem atingidos por vírus mais severos. 3) A vacina pode causar gripe? Não. Assim como explicado acima, por ser composta por partículas de vírus mortos, não existe possibilidade de a vacina da gripe causar gripe ou qualquer outra doença. 4) Já tomei a vacina no ano passado. Preciso ser vacinado novamente? Sim, a revacinação deve ser anual, já que a proteção conferida pela vacina cai progressivamente seis meses depois da aplicação e os subtipos do vírus influenza circulantes sofrem variações constantes. "Existe uma vigilância de quais vírus estão circulando, então, é importante renovar a dose para garantir a segurança", informa Ballalai. 5) A vacina da gripe também serve para resfriado? Não. Gripe e resfriado são doenças distintas e causadas por vírus diferentes. Por terem sintomas parecidos, as doenças são facilmente confundidas, mas a gripe costuma ser mais forte, durar menos tempo e apresentar maiores complicações','como problemas pulmonares e cardíacos.','13:10:00','Giulia Granchi','2019-05-01',1,2);


